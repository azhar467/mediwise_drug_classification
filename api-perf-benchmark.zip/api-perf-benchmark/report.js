// Copyright (c) 2026 Azhar Ahmed. All rights reserved.
// MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

const fs = require("fs");
const dir = process.argv[2] || ".";

// ---- config (thresholds) with safe fallbacks ----
let CFG = { warmupDriftPct:8, measureDriftPct:5, significanceP:0.05, outlierIqrMult:1.5, trimFraction:0.1 };
try {
  const c = JSON.parse(fs.readFileSync(__dirname + "/config.json","utf8"));
  if (c && c.thresholds) for (const k of Object.keys(CFG)) if (typeof c.thresholds[k]==="number") CFG[k]=c.thresholds[k];
} catch(e) { /* defaults are fine */ }

function die(msg){ console.error("report.js: " + msg); process.exit(1); }

// team-specific presentation (branding/labels) - edit report.config.json, not this file
let RC = {
  title:"API Performance Benchmark", subtitle:"Comparing two builds of a JSON HTTP service",
  authors:"", reviewer:"", team:"",
  labels:{ reference:"reference", candidate:"candidate" },
  credits:null,
  metricName:"server-side time",
  metricDefinition:"time-to-first-byte minus connection setup, so network transfer does not pollute the comparison"
};
try {
  const rc = JSON.parse(fs.readFileSync(__dirname + "/report.config.json","utf8"));
  RC = Object.assign(RC, rc);
  if (rc.labels) RC.labels = Object.assign({reference:"reference",candidate:"candidate"}, rc.labels);
} catch(e) { /* defaults are fine */ }

let ctx = {};
try { ctx = JSON.parse(fs.readFileSync(dir + "/run_context.json","utf8")); } catch(e) {}
const ctxLine = ctx.mode ? `Mode: <b>${ctx.mode}</b>${ctx.envA&&ctx.envB?` · <b>${ctx.envA}</b> vs <b>${ctx.envB}</b>`:(ctx.mode==='paired'&&ctx.environment?` (${ctx.environment})`:'')} · Collection: <b>${ctx.collection||'?'}</b> · ` : "";

const csvPath = dir + "/metrics.csv";
if (!fs.existsSync(csvPath)) die(`metrics.csv not found in '${dir}'. Did the benchmark run?`);
const raw = fs.readFileSync(csvPath,"utf8").trim();
const allLines = raw ? raw.split("\n") : [];
if (allLines.length < 2) die("metrics.csv has no data rows.");
const EXPECT = 12; // columns
const rows = allLines.slice(1).map((l,idx) => {
  const c = l.split(",");
  if (c.length < EXPECT) { console.error(`report.js: warning - skipping malformed metrics row ${idx+2} (${c.length} cols, expected ${EXPECT})`); return null; }
  const num = (v,d=0)=>{ const n=+v; return Number.isFinite(n)?n:d; };
  return { req:c[0], label:c[1], rep:num(c[2]), phase:c[3], code:c[4], bytes:num(c[5]),
           pre:num(c[6]), ttfb:num(c[7]), total:num(c[8]), ul:num(c[9]), count:num(c[10]), server:num(c[11]) };
}).filter(Boolean);
if (!rows.length) die("no valid rows in metrics.csv after parsing.");
const M=rows.filter(r=>r.phase==="measure"), W=rows.filter(r=>r.phase==="warmup");
const reqs=[...new Set(M.map(r=>r.req))], labels=[...new Set(M.map(r=>r.label))];
const pct=(a,p)=>a[Math.min(a.length-1,Math.ceil(p/100*a.length)-1)], mean=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const sd=a=>{const m=mean(a);return Math.sqrt(mean(a.map(x=>(x-m)**2)));};
const f3=x=>x.toFixed(3), f1=x=>x.toFixed(1), f2=x=>x.toFixed(2);

// ---- analysis helpers ----
// Mann-Whitney U with normal approximation -> two-sided p-value.
// Non-parametric: no assumption the latencies are normally distributed.
function erf(x){ // Abramowitz-Stegun
  const t=1/(1+0.3275911*Math.abs(x));
  const y=1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-0.284496736)*t+0.254829592)*t*Math.exp(-x*x);
  return x>=0?y:-y;
}
function normCdf(z){ return 0.5*(1+erf(z/Math.SQRT2)); }
// 95% CI on a mean via normal approx (n is large enough here: reps>=~10).
function meanCI(arr){
  const n=arr.length; if(n<2) return null;
  const m=mean(arr), s=Math.sqrt(arr.reduce((a,x)=>a+(x-m)**2,0)/(n-1));
  const se=s/Math.sqrt(n), h=1.96*se;
  return { mean:m, lo:m-h, hi:m+h, se };
}
function mannWhitney(a,b){
  const na=a.length, nb=b.length;
  if(na<3||nb<3) return {p:null, note:"too few samples"};
  const all=a.map(v=>({v,g:0})).concat(b.map(v=>({v,g:1}))).sort((x,y)=>x.v-y.v);
  // assign ranks (average for ties)
  let i=0; while(i<all.length){ let j=i; while(j+1<all.length && all[j+1].v===all[i].v) j++;
    const r=(i+j+2)/2; for(let k=i;k<=j;k++) all[k].rank=r; i=j+1; }
  let Ra=0; for(const o of all) if(o.g===0) Ra+=o.rank;
  const Ua=Ra-na*(na+1)/2, Ub=na*nb-Ua, U=Math.min(Ua,Ub);
  const mu=na*nb/2, sigma=Math.sqrt(na*nb*(na+nb+1)/12);
  if(sigma===0) return {p:1};
  const z=(U-mu)/sigma;
  return {p: 2*normCdf(-Math.abs(z))};
}
// trimmed mean: drop the top/bottom `frac` of sorted samples
function trimmedMean(sorted, frac){
  const k=Math.floor(sorted.length*frac);
  const t=sorted.slice(k, sorted.length-k);
  return t.length?mean(t):mean(sorted);
}
// outliers: samples beyond 1.5*IQR from the quartiles (Tukey)
function outlierInfo(sorted){
  const q=p=>sorted[Math.min(sorted.length-1,Math.ceil(p/100*sorted.length)-1)];
  const q1=q(25), q3=q(75), iqr=q3-q1;
  const lo=q1-CFG.outlierIqrMult*iqr, hi=q3+CFG.outlierIqrMult*iqr;
  const out=sorted.filter(v=>v<lo||v>hi);
  return {count:out.length, pct: sorted.length?out.length/sorted.length*100:0, hi, lo};
}
// warmup adequacy: did warmup server-times stop changing? Compare first vs second
// half of warmup reps for a label; large delta => not warm yet when measuring began.
function warmupAdequacy(label){
  const w=W.filter(r=>r.label===label&&r.code==="200").sort((a,b)=>a.rep-b.rep).map(r=>r.server);
  if(w.length<4) return {ok:null, note:"not enough warmup samples", deltaPct:null};
  const h=Math.floor(w.length/2);
  const first=mean(w.slice(0,h)), second=mean(w.slice(h));
  const deltaPct = first>0 ? (first-second)/first*100 : 0;
  // still dropping >8% across warmup halves => probably under-warmed
  return {ok: Math.abs(deltaPct)<=CFG.warmupDriftPct, deltaPct, first, second};
}
// drift within a label's MEASURE phase: first third vs last third of reps.
function driftInfo(label){
  const m=M.filter(r=>r.label===label&&r.code==="200").sort((a,b)=>a.rep-b.rep).map(r=>r.server);
  if(m.length<6) return {ok:null, deltaPct:null};
  const t=Math.floor(m.length/3);
  const start=mean(m.slice(0,t)), end=mean(m.slice(-t));
  const deltaPct=start>0?(end-start)/start*100:0;
  return {ok: Math.abs(deltaPct)<=CFG.measureDriftPct, deltaPct, start, end};
}

function stats(req,label){
  const g=M.filter(r=>r.req===req&&r.label===label&&r.code==="200");
  if(!g.length) return null;
  const s=g.map(r=>r.server).sort((a,b)=>a-b);
  const bytes=g[0].bytes;
  const meanServer=mean(s);
  return {
    n:s.length, mean:meanServer,
    p50:pct(s,50), p95:pct(s,95), p99:pct(s,99), max:s[s.length-1], min:s[0],
    cv:meanServer>0?sd(s)/meanServer*100:0,
    bytes, count:g[0].count,
    // throughput: payload bytes served per second of server-side time (MB/s)
    mbps: meanServer>0 ? (bytes/1048576)/meanServer : 0,
    trimmedMean: trimmedMean(s, CFG.trimFraction),           // 10% trimmed mean (robust to spikes)
    outliers: outlierInfo(s),                    // Tukey 1.5*IQR outlier count/%
    // network split (means, seconds): connection setup, server slice, download
    preMean: mean(g.map(r=>r.pre)),
    serverMean: meanServer,
    downloadMean: mean(g.map(r=>Math.max(0, r.total - r.ttfb))),
    totalMean: mean(g.map(r=>r.total)),
    samples: s,                                  // sorted server times for distribution
    series: g.slice().sort((a,b)=>a.rep-b.rep).map(r=>({rep:r.rep, server:r.server})) // per-rep trend
  };
}
function fails(req,label){ return M.filter(r=>r.req===req&&r.label===label&&r.code!=="200").length; }

const S={}; for(const r of reqs){S[r]={};for(const l of labels)S[r][l]=stats(r,l);}
const [A,B]=labels;
// display names: real environment names (cross-env) > config labels > raw data labels
const dispA = ctx.envA || RC.labels.reference || A;
const dispB = ctx.envB || RC.labels.candidate || B;

// per-request significance (is the A-vs-B difference real or noise?)
const sig={}; for(const r of reqs){ const a=S[r][A],b=S[r][B];
  sig[r] = (a&&b) ? mannWhitney(a.samples,b.samples) : {p:null}; }
// counts: of the requests where B was faster, how many are statistically significant
let sigWins=0, sigTotal=0;
// warmup adequacy + measure-phase drift, per label
const warmA=warmupAdequacy(A), warmB=warmupAdequacy(B);
const driftA=driftInfo(A), driftB=driftInfo(B);
// total outliers across measure samples
const outTotal=reqs.reduce((acc,r)=>{const a=S[r][A],b=S[r][B];return acc+(a?a.outliers.count:0)+(b?b.outliers.count:0);},0);

// gain per request (null if either side missing a healthy sample) -> down B can't win
const gains=reqs.map(r=>{const a=S[r][A],b=S[r][B];return (a&&b)?(a.mean-b.mean)/Math.max(a.mean,b.mean)*100:null;});
const comparable=reqs.filter((r,i)=>gains[i]!==null);
const validGains=gains.filter(g=>g!==null);
const wins=validGains.filter(g=>g>0).length;
const avgAll=validGains.length?mean(validGains):0;
// significant wins: B faster AND p<0.05
reqs.forEach((r,i)=>{ if(gains[i]!=null){ sigTotal++; const p=sig[r]&&sig[r].p; if(gains[i]>0 && p!=null && p<CFG.significanceP) sigWins++; } });
// 95% CI on the overall mean-server-time difference (A - B), pooled across comparable requests.
const aAll=M.filter(r=>r.label===A&&r.code==="200"&&comparable.includes(r.req)).map(r=>r.server);
const bAll=M.filter(r=>r.label===B&&r.code==="200"&&comparable.includes(r.req)).map(r=>r.server);
let deltaCI=null;
if(aAll.length>1 && bAll.length>1){
  const ma=mean(aAll), mb=mean(bAll);
  const va=aAll.reduce((a,x)=>a+(x-ma)**2,0)/(aAll.length-1);
  const vb=bAll.reduce((a,x)=>a+(x-mb)**2,0)/(bAll.length-1);
  const se=Math.sqrt(va/aAll.length+vb/bAll.length);
  const diff=ma-mb, h=1.96*se;             // seconds, positive = B faster
  const denom=Math.max(ma,mb)||1;
  deltaCI={ diffLo:diff-h, diffHi:diff+h, pctLo:(diff-h)/denom*100, pct:(diff)/denom*100, pctHi:(diff+h)/denom*100 };
}
const anyWarmupConcern = (warmB.ok===false) || (warmA.ok===false);
const anyDriftConcern  = (driftA.ok===false) || (driftB.ok===false);

const fails_total=M.filter(r=>r.code!=="200").length;
const bFails=M.filter(r=>r.label===B&&r.code!=="200").length;
const aFails=M.filter(r=>r.label===A&&r.code!=="200").length;
const bMissing=reqs.filter(r=>!S[r][B]).length;
const bDown=bMissing===reqs.length;

const equiv=reqs.map(r=>{const a=S[r][A],b=S[r][B];return a&&b&&a.bytes===b.bytes;});
const nMin=Math.min(...comparable.map(r=>S[r][A]?S[r][A].n:0), ...comparable.map(r=>S[r][B]?S[r][B].n:0));
const wWarm=mean(W.filter(r=>r.label===B&&r.code==="200").map(r=>r.server));
const wSteady=mean(M.filter(r=>r.label===B&&r.code==="200").map(r=>r.server));

// run-level totals for the summary strip
const totalCalls=M.length + W.length;
const totalMeasure=M.length;
const totalBytesMoved=M.filter(r=>r.code==="200").reduce((x,r)=>x+r.bytes,0);

let verdict, verdictGood=false;
if (bDown) {
  verdict = `${dispB} produced no healthy (HTTP 200) responses on any of ${reqs.length} requests `
          + `(${bFails} failed calls). The environment appears to be down or terminated, `
          + `so no performance comparison is possible. Bring ${dispB} back up and re-run.`;
} else if (bMissing > 0 || bFails > 0) {
  verdict = `${dispB} had failures during the run: ${bFails} failed calls, and ${bMissing} of ${reqs.length} `
          + `requests had no healthy sample. Of the ${comparable.length} requests where both environments `
          + `responded successfully, ${dispB} was faster on ${wins} (average ${f1(avgAll)}% on mean server time). `
          + `Because ${dispB} did not return healthy responses everywhere, this run does not support adopting `
          + `${dispB} on performance grounds - investigate the failures first.`;
} else if (wins > comparable.length/2) {
  verdictGood=true;
  verdict = `${dispB} returned identical responses on all ${comparable.length} requests and was faster on ${wins} `
          + `of ${comparable.length} (average ${f1(avgAll)}% on mean server time; ${sigWins} of those `
          + `statistically significant at p&lt;0.05), with ${fails_total} failed calls.`;
} else {
  verdict = `${dispB} returned identical responses on all ${comparable.length} requests, but was faster on only ${wins} `
          + `of ${comparable.length} (average ${f1(avgAll)}% on mean server time). This result does not support `
          + `adopting ${dispB} on performance grounds without further investigation.`;
}

// ---- payload handed to the browser for client-side charting ----
const payload = {
  A, B, reqs,
  shortReqs: reqs.map(r=>r.replace("parties_","")),
  gains,
  stats: S,            // S[req][label] = {mean,p50,p95,p99,max,min,cv,mbps,pre/server/download Mean, samples, series, ...}
  equiv,
  sigP: reqs.map(r=>sig[r]?sig[r].p:null)
};

const html=`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${RC.title} — ${dispA} vs ${dispB}</title>
<script>${fs.readFileSync(__dirname + "/chartjs-inline.js","utf8")}</script>
<style>
  :root{
    --ink:#1a1d21; --muted:#5b6470; --line:#e2e6ea; --panel:#fbfcfd;
    --before:#7c8794; --after:#1f7a4d; --after-soft:#e7f3ec;
    --warn:#b3401f; --warn-soft:#fbece7;
    --accent:#1f7a4d;
  }
  *{box-sizing:border-box}
  body{font-family:"Inter",-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:var(--ink);
       margin:0;background:#f2f4f6;-webkit-font-smoothing:antialiased}
  .wrap{max-width:1080px;margin:0 auto;padding:32px 24px 64px}
  header h1{font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);
            font-weight:600;margin:0 0 6px}
  header h2{font-size:30px;line-height:1.15;margin:0 0 4px;font-weight:700}
  header .by{color:var(--muted);font-size:13px;margin:8px 0 0}
  .verdict{border-left:4px solid ${verdictGood?'var(--after)':'var(--warn)'};
           background:${verdictGood?'var(--after-soft)':'var(--warn-soft)'};
           padding:16px 18px;border-radius:0 10px 10px 0;font-size:15.5px;line-height:1.5;margin:22px 0}
  .verdict b{font-weight:700}
  .exec{display:flex;align-items:baseline;gap:12px;padding:18px 20px;border-radius:12px;margin:20px 0;font-size:17px;font-weight:600;line-height:1.45}
  .exec.good{background:#10331f;color:#eafaf0}
  .exec.warn{background:#3a1c10;color:#fdeee7}
  .exec .lbl{font-size:11px;letter-spacing:.12em;text-transform:uppercase;font-weight:700;opacity:.7;flex:0 0 auto}
  .strip{display:flex;flex-wrap:wrap;gap:1px;background:var(--line);border:1px solid var(--line);
         border-radius:10px;overflow:hidden;margin:18px 0}
  .strip .cell{background:#fff;flex:1 1 140px;padding:14px 16px}
  .strip .cell .v{font-size:22px;font-weight:700;line-height:1}
  .strip .cell .k{font-size:11.5px;color:var(--muted);margin-top:5px;text-transform:uppercase;letter-spacing:.05em}
  .kpis{display:flex;flex-wrap:wrap;gap:12px;margin:18px 0}
  .kpi{flex:1 1 150px;border:1px solid var(--line);border-radius:10px;background:#fff;padding:16px 18px;text-align:center}
  .kpi .v{font-size:26px;font-weight:700;display:block;line-height:1}
  .kpi .k{font-size:12px;color:var(--muted);margin-top:6px}
  .panel{border:1px solid var(--line);border-radius:12px;background:#fff;padding:20px 22px;margin:16px 0}
  .panel h3{margin:0 0 4px;font-size:16px;font-weight:700}
  .panel .sub{color:var(--muted);font-size:12.5px;margin:0 0 14px}
  .chartbox{position:relative;height:300px}
  .chartbox.tall{height:340px}
  .note{color:var(--muted);font-size:12.5px;line-height:1.5}
  .warnbox{border-left:4px solid var(--warn);background:var(--warn-soft);padding:12px 16px;border-radius:0 10px 10px 0;font-size:13.5px;margin:16px 0}
  table{border-collapse:collapse;width:100%;font-size:12.5px;margin-top:6px}
  th,td{border-bottom:1px solid var(--line);padding:8px 10px;text-align:center}
  th{background:var(--panel);font-weight:600;color:var(--muted);text-transform:uppercase;font-size:10.5px;letter-spacing:.04em}
  td.req{text-align:left;font-weight:600}
  .pill{font-weight:700}.pos{color:var(--after)}.neg{color:var(--warn)}
  .legend{display:flex;gap:16px;font-size:12px;color:var(--muted);margin-bottom:10px}
  .legend i{display:inline-block;width:11px;height:11px;border-radius:2px;margin-right:5px;vertical-align:-1px}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  @media(max-width:720px){.grid2{grid-template-columns:1fr}.chartbox{height:260px}}
  .meta{font-size:12px;color:var(--muted);margin-top:4px}
  footer.credits{margin-top:28px;padding-top:18px;border-top:1px solid var(--line);text-align:center}
  footer.credits .roles{display:flex;flex-wrap:wrap;gap:22px;justify-content:center;font-size:12px;color:var(--muted)}
  footer.credits .roles span{display:flex;flex-direction:column;gap:2px}
  footer.credits .roles b{font-size:10px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink);font-weight:700}
  footer.credits .copyright{margin-top:14px;font-size:11.5px;color:var(--muted)}
</style></head><body><div class="wrap">

<header>
  <h1>${RC.subtitle}</h1>
  <h2>${dispA} vs ${dispB}</h2>
  <p class="by">${RC.authors?`Benchmark: <b>${RC.authors}</b>`:""}${RC.reviewer?` · Review: <b>${RC.reviewer}</b>`:""}${RC.team?` · ${RC.team}`:""}<br>
  <span class="meta">${ctxLine}${RC.metricName.charAt(0).toUpperCase()+RC.metricName.slice(1)} = ${RC.metricDefinition} · generated ${new Date().toLocaleString()}</span></p>
</header>

${(()=>{
  // one-line recommendation for a skim-reader / non-engineer
  let rec, cls;
  if (bDown) { rec=`Do not adopt — ${dispB} did not respond (environment down). No comparison possible.`; cls="warn"; }
  else if (bMissing>0 || bFails>0) { rec=`Do not adopt yet — ${dispB} had failures (${bFails} failed calls). Fix and re-run before judging performance.`; cls="warn"; }
  else if (anyWarmupConcern || anyDriftConcern) { rec=`Treat with caution — results may be contaminated by ${anyWarmupConcern?"insufficient warmup":""}${anyWarmupConcern&&anyDriftConcern?" and ":""}${anyDriftConcern?"server drift":""}. See Run quality below.`; cls="warn"; }
  else if (wins>comparable.length/2 && sigWins>=Math.ceil(wins/2)) {
    const ciCrossesZero = deltaCI && deltaCI.pctLo <= 0;
    if (ciCrossesZero) {
      rec=`Lean adopt, verify — ${dispB} faster on ${wins} of ${comparable.length} (${sigWins} significant per-request), but the pooled 95% CI (${f1(deltaCI.pctLo)}–${f1(deltaCI.pctHi)}%) crosses zero. Per-request wins are real; the overall average is noisy. More reps would tighten it.`; cls="warn";
    } else {
      rec=`Recommend adopting ${dispB} — faster on ${wins} of ${comparable.length} requests (${f1(avgAll)}% avg${deltaCI?`, 95% CI ${f1(deltaCI.pctLo)}–${f1(deltaCI.pctHi)}%`:""}), ${sigWins} statistically significant, identical output, ${fails_total} failures.`; cls="good";
    }
  } else if (wins>comparable.length/2) {
    rec=`Lean adopt, verify — ${dispB} faster on ${wins} of ${comparable.length} but only ${sigWins} clear the noise floor. Consider more reps before committing.`; cls="warn";
  } else {
    rec=`Do not adopt on performance grounds — ${dispB} faster on only ${wins} of ${comparable.length} requests; difference is within noise.`; cls="warn";
  }
  return `<div class="exec ${cls}"><span class="lbl">Recommendation</span>${rec}</div>`;
})()}

<div class="verdict"><b>Verdict.</b> ${verdict}</div>

${(bDown||bMissing>0||bFails>0)?`<div class="warnbox"><b>Health warning.</b> ${dispB} had ${bFails} failed call(s); ${bMissing} of ${reqs.length} request(s) had no healthy sample. Charts below cover only requests where both environments returned HTTP 200.</div>`:""}

${(()=>{
  const items=[];
  const ok=t=>`<span style="color:var(--after)">✓</span> ${t}`;
  const bad=t=>`<span style="color:var(--warn)">⚠</span> ${t}`;
  // significance
  if(sigTotal>0) items.push(`${sigWins===wins&&wins>0?ok(''):bad('')}<b>Significance:</b> ${sigWins} of ${wins} wins are statistically significant (Mann-Whitney p&lt;0.05). ${sigWins<wins?'The rest are within run-to-run noise.':'All wins clear the noise floor.'}`);
  // warmup
  if(warmB.ok===false) items.push(bad(`<b>Warmup:</b> ${dispB} server time was still changing ${f1(Math.abs(warmB.deltaPct))}% across the warmup window — JIT/codegen may not have settled. Consider more warmups.`));
  else if(warmB.ok===true) items.push(ok(`<b>Warmup:</b> ${dispB} stabilized during warmup (${f1(Math.abs(warmB.deltaPct))}% change).`));
  // drift
  if(driftA.ok===false||driftB.ok===false){
    const which=[]; if(driftA.ok===false)which.push(`${dispA} ${f1(driftA.deltaPct)}%`); if(driftB.ok===false)which.push(`${dispB} ${f1(driftB.deltaPct)}%`);
    items.push(bad(`<b>Drift:</b> server time drifted across the measure window (${which.join(', ')}). ${ctx.mode==='paired'?'In before/after mode this directly threatens the comparison — re-run on a quiet host.':'Cluster load may have shifted mid-run.'}`));
  } else if(driftA.ok===true&&driftB.ok===true) items.push(ok(`<b>Drift:</b> stable across the measure window (≤5%).`));
  // outliers
  if(outTotal>0) items.push(`${outTotal>nMin*reqs.length*0.05?bad(''):ok('')}<b>Outliers:</b> ${outTotal} sample(s) beyond 1.5×IQR. The detail table shows 10% trimmed means alongside raw means so a single spike can't swing the verdict.`);
  const concern=anyWarmupConcern||anyDriftConcern;
  return `<div class="panel" style="border-left:4px solid ${concern?'var(--warn)':'var(--after)'}">
    <h3>Run quality</h3>
    <p class="sub">Whether you can trust the numbers below — independent of who won.</p>
    <ul style="margin:0;padding-left:4px;list-style:none;font-size:13.5px;line-height:1.9">${items.map(i=>`<li>${i}</li>`).join("")}</ul>
  </div>`;
})()}

<div class="strip">
  <div class="cell"><div class="v">${comparable.length}/${reqs.length}</div><div class="k">requests compared</div></div>
  <div class="cell"><div class="v">${nMin}</div><div class="k">measured per cell</div></div>
  <div class="cell"><div class="v">${totalCalls.toLocaleString()}</div><div class="k">total HTTP calls</div></div>
  <div class="cell"><div class="v">${(totalBytesMoved/1073741824).toFixed(2)} GB</div><div class="k">payload served (200s)</div></div>
  <div class="cell"><div class="v">${fails_total}</div><div class="k">failed calls</div></div>
</div>

<div class="kpis">
  <div class="kpi"><span class="v">${wins}/${comparable.length}</span><span class="k">faster with ${dispB}</span></div>
  <div class="kpi"><span class="v">${f1(avgAll)}%</span><span class="k">avg Δ${deltaCI?` · 95% CI ${f1(deltaCI.pctLo)}–${f1(deltaCI.pctHi)}%`:""}</span></div>
  <div class="kpi"><span class="v">${equiv.filter(Boolean).length===comparable.length&&comparable.length>0?"100%":"CHECK"}</span><span class="k">output equivalence</span></div>
  <div class="kpi"><span class="v">${bFails}</span><span class="k">${dispB} failed calls</span></div>
  <div class="kpi"><span class="v">${wWarm&&wSteady?f1((wWarm-wSteady)/wWarm*100)+"%":"n/a"}</span><span class="k">${dispB} warmup→steady gain</span></div>
</div>

<div class="panel">
  <h3>Mean server time, relative change per request</h3>
  <p class="sub">Positive = ${dispB} faster than ${dispA}. Hover for exact values.</p>
  <div class="chartbox"><canvas id="deltaChart"></canvas></div>
</div>

<div class="panel">
  <h3>Latency distribution (server-side time)</h3>
  <p class="sub">Box = P25–P75, whiskers = min/max, line = median. Tighter boxes mean steadier latency — the main thing a runtime serializer should improve.</p>
  <div class="legend"><span><i style="background:var(--before)"></i>${dispA}</span><span><i style="background:var(--after)"></i>${dispB}</span></div>
  <div class="chartbox tall"><canvas id="distChart"></canvas></div>
</div>

<div class="grid2">
  <div class="panel"><h3>P50 / P95 / P99 / max</h3><p class="sub">Tail latency. Pick a request:</p>
    <select id="tailReq" style="margin-bottom:10px;padding:6px 8px;border:1px solid var(--line);border-radius:6px"></select>
    <div class="chartbox"><canvas id="tailChart"></canvas></div></div>
  <div class="panel"><h3>Consistency (CV %)</h3><p class="sub">Std-dev ÷ mean. Lower = steadier.</p>
    <div class="chartbox"><canvas id="cvChart"></canvas></div></div>
</div>

<div class="panel">
  <h3>Throughput — MB/s of payload per second of server time</h3>
  <p class="sub">Payload size ÷ mean server time. Normalizes for the fact that requests return very different sizes; higher is faster serialization.</p>
  <div class="legend"><span><i style="background:var(--before)"></i>${dispA}</span><span><i style="background:var(--after)"></i>${dispB}</span></div>
  <div class="chartbox"><canvas id="mbpsChart"></canvas></div>
</div>

<div class="panel">
  <h3>Where the time goes — ${dispB}</h3>
  <p class="sub">Mean seconds split into connection setup, server slice, and response download. Shows how much of total time the serializer change can even touch.</p>
  <div class="legend"><span><i style="background:#c9d2da"></i>connect</span><span><i style="background:var(--after)"></i>server</span><span><i style="background:#9ec6b0"></i>download</span></div>
  <div class="chartbox"><canvas id="splitChart"></canvas></div>
</div>

<div class="panel">
  <h3>Per-rep trend (drift detection)</h3>
  <p class="sub">Server time across measure reps. Flat lines = stable run; upward/downward slopes mean cluster load or JIT drift contaminated the comparison — important for before/after runs. Pick a request:</p>
  <select id="trendReq" style="margin-bottom:10px;padding:6px 8px;border:1px solid var(--line);border-radius:6px"></select>
  <div class="legend"><span><i style="background:var(--before)"></i>${dispA}</span><span><i style="background:var(--after)"></i>${dispB}</span></div>
  <div class="chartbox tall"><canvas id="trendChart"></canvas></div>
</div>

<div class="panel">
  <h3>Detail — ${dispA} / ${dispB}</h3>
  <table><thead><tr><th>request</th><th>n</th><th>mean s</th><th>trim mean</th><th>P50</th><th>P95</th><th>P99</th><th>max</th><th>CV</th><th>MB/s</th><th>size</th><th>Δ mean</th><th>p-value</th><th>equiv</th></tr></thead><tbody>
  ${reqs.map((r,i)=>{
    const a=S[r][A],b=S[r][B];
    if(!a||!b){const why=!b?`${dispB} no healthy data (${fails(r,B)} failed)`:`${dispA} no healthy data (${fails(r,A)} failed)`;
      return `<tr><td class="req">${r}</td><td colspan="13" style="color:var(--warn)">missing — ${why}</td></tr>`;}
    const g=gains[i],cls=g>0?"pos":"neg";
    const p=sig[r]?sig[r].p:null;
    const pCell = p==null ? "—" : (p<0.001?"&lt;0.001":f3(p)) + (p<0.05?' <span style="color:var(--after)">✓</span>':' <span style="color:var(--muted)">ns</span>');
    return `<tr><td class="req">${r}</td><td>${a.n}/${b.n}</td><td>${f3(a.mean)} / ${f3(b.mean)}</td><td>${f3(a.trimmedMean)} / ${f3(b.trimmedMean)}</td><td>${f3(a.p50)} / ${f3(b.p50)}</td><td>${f3(a.p95)} / ${f3(b.p95)}</td><td>${f3(a.p99)} / ${f3(b.p99)}</td><td>${f3(a.max)} / ${f3(b.max)}</td><td>${f1(a.cv)} / ${f1(b.cv)}</td><td>${f1(a.mbps)} / ${f1(b.mbps)}</td><td>${(a.bytes/1048576).toFixed(1)} MB${a.bytes!==b.bytes?" ⚠":""}</td><td class="pill ${cls}">${g>0?"+":""}${f1(g)}%</td><td>${pCell}</td><td>${equiv[i]?"✓":"⚠"}</td></tr>`;
  }).join("")}
  </tbody></table>
</div>

<div class="panel">
  <h3>How to read this</h3>
  <p class="note">Each request ran ${nMin}+ times against each environment. We measure the <b>server-side slice</b> (time-to-first-byte minus connection setup), so network transfer of the large responses does not pollute the comparison. <b>P50</b> is the typical experience; <b>P95/P99/max</b> are the slow tail, where a runtime serializer most helps or hurts; <b>CV</b> is how consistent the times are (lower = steadier); <b>throughput</b> normalizes speed by payload size. ⚠ in size/equiv means the two environments produced different output — investigate before trusting the timing. ${dispA} = current build · ${dispB} = candidate build.</p>
</div>

<div class="panel">
  <h3>Scope &amp; risks</h3>
  <p class="note">Steady-state, single-stream latency; concurrency/load not in scope. Warmup excluded from measurements (${dispB} averaged ${f3(wWarm)}s warmup vs ${f3(wSteady)}s steady — expect slower first calls after deploy while JIT settles). Δ = relative difference of mean server-side time; positive = ${dispB} faster.</p>
</div>

${RC.credits ? `<footer class="credits">
  <div class="roles">
    ${RC.credits.developer?`<span><b>Developer</b>${RC.credits.developer}</span>`:""}
    ${RC.credits.architect?`<span><b>Architect</b>${RC.credits.architect}</span>`:""}
    ${RC.credits.productOwner?`<span><b>Product Owner</b>${RC.credits.productOwner}</span>`:""}
    ${RC.credits.scrumMaster?`<span><b>Scrum Master</b>${RC.credits.scrumMaster}</span>`:""}
    ${RC.credits.team?`<span><b>Team</b>${RC.credits.team}</span>`:""}
  </div>
  <div class="copyright">© ${new Date().getFullYear()} ${RC.credits.copyrightHolder||RC.authors}. All rights reserved.</div>
</footer>` : ""}

<script>
const D=${JSON.stringify(payload)};
const C={before:'#7c8794',after:'#1f7a4d',line:'#e2e6ea',ink:'#1a1d21',pos:'#1f7a4d',neg:'#b3401f'};
Chart.defaults.font.family='Inter,Segoe UI,Arial,sans-serif';
Chart.defaults.font.size=11.5; Chart.defaults.color='#5b6470';
const grid={grid:{color:C.line},border:{display:false}};
const st=(r,l)=>D.stats[r][l];

// 1) delta bars
new Chart(deltaChart,{type:'bar',
  data:{labels:D.shortReqs,datasets:[{data:D.gains.map(g=>g==null?0:+g.toFixed(2)),
    backgroundColor:D.gains.map(g=>g==null?'#cfd6dc':g>0?C.pos:C.neg)}]},
  options:{plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>D.gains[c.dataIndex]==null?'no data':(D.gains[c.dataIndex]>0?'+':'')+c.parsed.y+'% '+D.B+' faster'}}},
    scales:{y:{...grid,title:{display:true,text:'% faster ('+D.B+')'}},x:grid}}});

// 2) distribution as box-like bars (P25-P75) with median + whiskers via custom
const q=(s,p)=>s[Math.min(s.length-1,Math.ceil(p/100*s.length)-1)];
function boxData(l){return D.reqs.map(r=>{const x=st(r,l);if(!x)return null;const s=x.samples;
  return {min:x.min,p25:q(s,25),p50:x.p50,p75:q(s,75),max:x.max};});}
const before=boxData(D.A),after=boxData(D.B);
// emulate boxplot with floating bars: dataset = [p25,p75] using base
new Chart(distChart,{type:'bar',
  data:{labels:D.shortReqs,datasets:[
    {label:D.A,data:before.map(b=>b?[b.p25,b.p75]:[0,0]),backgroundColor:C.before,borderWidth:0,categoryPercentage:.7,barPercentage:.8},
    {label:D.B,data:after.map(b=>b?[b.p25,b.p75]:[0,0]),backgroundColor:C.after,borderWidth:0,categoryPercentage:.7,barPercentage:.8}]},
  options:{plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>{const arr=c.datasetIndex?after:before;const b=arr[c.dataIndex];return b?[c.dataset.label+':','  min '+b.min.toFixed(3)+'  P25 '+b.p25.toFixed(3)+'  med '+b.p50.toFixed(3)+'  P75 '+b.p75.toFixed(3)+'  max '+b.max.toFixed(3)]:'no data'}}}},
    scales:{y:{...grid,title:{display:true,text:'server time (s)'}},x:grid}}});

// 3) tail latency per request (dropdown)
const tailSel=document.getElementById('tailReq');
D.reqs.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=D.shortReqs[i];tailSel.appendChild(o);});
let tailC;
function drawTail(i){const r=D.reqs[i];const a=st(r,D.A),b=st(r,D.B);
  const mk=x=>x?[x.p50,x.p95,x.p99,x.max]:[0,0,0,0];
  if(tailC)tailC.destroy();
  tailC=new Chart(tailChart,{type:'bar',
    data:{labels:['P50','P95','P99','max'],datasets:[
      {label:D.A,data:mk(a),backgroundColor:C.before},
      {label:D.B,data:mk(b),backgroundColor:C.after}]},
    options:{plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>c.dataset.label+': '+c.parsed.y.toFixed(3)+'s'}}},
      scales:{y:{...grid,title:{display:true,text:'seconds'}},x:grid}}});}
tailSel.onchange=e=>drawTail(+e.target.value); drawTail(0);

// 4) CV grouped
new Chart(cvChart,{type:'bar',
  data:{labels:D.shortReqs,datasets:[
    {label:D.A,data:D.reqs.map(r=>st(r,D.A)?+st(r,D.A).cv.toFixed(1):0),backgroundColor:C.before},
    {label:D.B,data:D.reqs.map(r=>st(r,D.B)?+st(r,D.B).cv.toFixed(1):0),backgroundColor:C.after}]},
  options:{plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>c.dataset.label+': '+c.parsed.y+'% CV'}}},
    scales:{y:{...grid,title:{display:true,text:'CV %'}},x:grid}}});

// 5) throughput
new Chart(mbpsChart,{type:'bar',
  data:{labels:D.shortReqs,datasets:[
    {label:D.A,data:D.reqs.map(r=>st(r,D.A)?+st(r,D.A).mbps.toFixed(1):0),backgroundColor:C.before},
    {label:D.B,data:D.reqs.map(r=>st(r,D.B)?+st(r,D.B).mbps.toFixed(1):0),backgroundColor:C.after}]},
  options:{plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>c.dataset.label+': '+c.parsed.y+' MB/s'}}},
    scales:{y:{...grid,title:{display:true,text:'MB/s'}},x:grid}}});

// 6) server vs network split (stacked) for B
new Chart(splitChart,{type:'bar',
  data:{labels:D.shortReqs,datasets:[
    {label:'connect',data:D.reqs.map(r=>st(r,D.B)?+st(r,D.B).preMean.toFixed(3):0),backgroundColor:'#c9d2da'},
    {label:'server',data:D.reqs.map(r=>st(r,D.B)?+st(r,D.B).serverMean.toFixed(3):0),backgroundColor:C.after},
    {label:'download',data:D.reqs.map(r=>st(r,D.B)?+st(r,D.B).downloadMean.toFixed(3):0),backgroundColor:'#9ec6b0'}]},
  options:{plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>c.dataset.label+': '+c.parsed.y.toFixed(3)+'s'}}},
    scales:{y:{...grid,stacked:true,title:{display:true,text:'mean seconds'}},x:{...grid,stacked:true}}}});

// 7) per-rep trend (dropdown)
const trendSel=document.getElementById('trendReq');
D.reqs.forEach((r,i)=>{const o=document.createElement('option');o.value=i;o.textContent=D.shortReqs[i];trendSel.appendChild(o);});
let trendC;
function drawTrend(i){const r=D.reqs[i];const a=st(r,D.A),b=st(r,D.B);
  const reps=(a?a.series:b?b.series:[]).map(p=>p.rep);
  if(trendC)trendC.destroy();
  trendC=new Chart(trendChart,{type:'line',
    data:{labels:reps,datasets:[
      {label:D.A,data:a?a.series.map(p=>p.server):[],borderColor:C.before,backgroundColor:C.before,tension:.2,pointRadius:2},
      {label:D.B,data:b?b.series.map(p=>p.server):[],borderColor:C.after,backgroundColor:C.after,tension:.2,pointRadius:2}]},
    options:{plugins:{legend:{position:'bottom'},tooltip:{callbacks:{label:c=>c.dataset.label+' rep '+c.label+': '+c.parsed.y.toFixed(3)+'s'}}},
      scales:{y:{...grid,title:{display:true,text:'server time (s)'}},x:{...grid,title:{display:true,text:'measure rep'}}}}});}
trendSel.onchange=e=>drawTrend(+e.target.value); drawTrend(0);
</script>
</div></body></html>`;
fs.writeFileSync(dir + "/dashboard.html",html);
console.log("Wrote dashboard.html");
