# Copyright (c) 2026 Azhar Ahmed. All rights reserved.
# MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

# ============================================================
# bench-paired.ps1 - paired before/after on a SINGLE host.
#
# Flow:
#   1) Capture BEFORE  (develop/master currently deployed)  -> label "baseline"
#   2) PAUSE - you deploy blackbird in place onto the same host
#   3) Re-check health, then capture AFTER (blackbird)       -> label "blackbird"
#   4) compare.js / report.js consume the same run folder unchanged.
#
# Unlike bench.ps1 (two live hosts, interleaved A/B), here the two halves are
# separated in time on ONE url. That means slow drift (cluster load, JIT, noisy
# neighbours) is NOT cancelled by interleaving - keep the window short and the
# box quiet. Warmups run in BOTH halves so the after-phase JIT is warm.
# ============================================================
param(
    [string[]]$Only = @(),
    [int]$Reps = 30,        # measured reps per request
    [int]$Warmups = 10,     # discarded warmups per request
    [string]$Environment = "preprod", # creds.json entry to benchmark (e.g. preprod, prod)
    [string]$RunDir = ""    # caller-supplied run folder; auto-generated if empty
)
$reps    = $Reps
$warmups = $Warmups

# ---------- CREDENTIALS ----------
# Expected creds.json shape (token endpoint is SHARED; only host + secrets vary):
#   {
#     "tokenUrl": "https://auth.shared.../oauth/token",
#     "preprod": { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-preprod.../" },
#     "prod":    { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-prod.../" },
#     ...
#   }
$creds = Get-Content "creds.json" -Raw | ConvertFrom-Json
$e = $creds.$Environment
if (-not $e) { Write-Host "creds.json has no entry named '$Environment'." -ForegroundColor Red; exit 1 }

# Shared token endpoint. New shape: top-level $creds.tokenUrl.
# Fallback: old shape where each entry carried its own .url token endpoint.
$tokenUrl = if ($creds.tokenUrl) { $creds.tokenUrl } elseif ($e.url) { $e.url } else {
    Write-Host "No token endpoint found (expected creds.tokenUrl)." -ForegroundColor Red; exit 1
}

# App host to benchmark. New shape: per-entry .hostUrl.
$hostUrl = if ($e.hostUrl) { $e.hostUrl } else {
    Write-Host "creds.json entry '$Environment' has no hostUrl (the app URL to benchmark)." -ForegroundColor Red; exit 1
}

Write-Host "Environment : $Environment" -ForegroundColor Cyan
Write-Host "Token URL   : $tokenUrl" -ForegroundColor DarkGray
Write-Host "App host    : $hostUrl" -ForegroundColor DarkGray

function Get-Token {
    $resp = curl.exe -k -s -X POST $tokenUrl -d "grant_type=client_credentials&client_id=$($e.id)&client_secret=$($e.secret)&scope=$($e.scope)"
    $tok = ($resp | ConvertFrom-Json).access_token
    if (-not $tok) { Write-Host "TOKEN FETCH FAILED : $resp" -ForegroundColor Red; exit 1 }
    Write-Host "Token OK (len $($tok.Length))"
    return $tok
}

function Refresh-TokenIfNeeded {
    $age = (New-TimeSpan -Start $script:tokenMintedAt -End (Get-Date)).TotalMinutes
    if ($age -ge 45) {
        Write-Host "  (token age $([int]$age)min -> refreshing)" -ForegroundColor DarkYellow
        $script:token = Get-Token
        $script:tokenMintedAt = Get-Date
    }
}

$script:token = Get-Token
$script:tokenMintedAt = Get-Date

# ---------- requests ----------
$requests = Get-Content "requests.json" -Raw | ConvertFrom-Json
$only = $Only
if ($only.Count -gt 0) {
    $requests = $requests | Where-Object { $only -contains $_.name }
    Write-Host "Running SUBSET: $($requests.name -join ', ')" -ForegroundColor Cyan
} else {
    Write-Host "Running ALL $($requests.Count) requests" -ForegroundColor Cyan
}
if ($requests.Count -eq 0) { Write-Host "No requests matched - check names against requests.json" -ForegroundColor Red; exit 1 }

# ---------- run folder ----------
if ($RunDir -ne "") {
    $runDir = $RunDir
} else {
    $stamp  = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $runDir = "runs\paired_${Environment}_${stamp}_reps${reps}_warm${warmups}"
}
New-Item -ItemType Directory -Force -Path $runDir, "$runDir\responses\baseline", "$runDir\responses\blackbird", "$runDir\requests" | Out-Null
$runDir | Out-File "last_run.txt" -Encoding ascii -NoNewline
$csv = "$runDir\metrics.csv"
"request,label,rep,phase,http_code,resp_bytes,pretransfer_s,ttfb_s,total_s,upload_Bps,array_count,server_s" | Out-File $csv -Encoding utf8

# ---------- health probe against the single host ----------
function Test-Host {
    $req = $requests[0]
    $probeBody = Join-Path $env:TEMP "bb_probe_paired.json"
    [System.IO.File]::WriteAllText($probeBody, $req.body)
    $code = curl.exe -k -s -o NUL -X PUT `
        -H "Authorization: Bearer $($script:token)" `
        -H "Content-Type: application/json" `
        --data-binary "@$probeBody" `
        -w "%{http_code}" `
        --connect-timeout 10 --max-time 30 `
        ($hostUrl + $req.path)
    Remove-Item $probeBody -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($code)) { $code = "000" }
    return $code
}

# ---------- one call; $label decides which folder/CSV label it lands in ----------
function Invoke-Bench($req, $label, $i, $phase) {
    if ($phase -eq "measure" -and $i -eq 1) {
        $respFile = "$runDir\responses\$label\resp_$($req.name)_measure_1.json"
    } else {
        $respFile = "NUL"
    }
    $bodyFile = "$runDir\requests\body_$($req.name).json"
    $url      = $hostUrl + $req.path

    [System.IO.File]::WriteAllText("$PWD\$bodyFile", $req.body)

    $out = curl.exe -k -s -o $respFile -X PUT -H "Authorization: Bearer $($script:token)" -H "Content-Type: application/json" --data-binary "@$bodyFile" -w "%{http_code},%{size_download},%{time_pretransfer},%{time_starttransfer},%{time_total},%{speed_upload}" $url

    if (-not $out) { Write-Host "CURL FAILED for $($req.name) / $label"; return $null }
    $p = $out.Split(',')

    if ($p[0] -eq "401") {
        Write-Host "  401 on $($req.name)/$label -> refreshing token and retrying" -ForegroundColor DarkYellow
        $script:token = Get-Token
        $script:tokenMintedAt = Get-Date
        $out = curl.exe -k -s -o $respFile -X PUT -H "Authorization: Bearer $($script:token)" -H "Content-Type: application/json" --data-binary "@$bodyFile" -w "%{http_code},%{size_download},%{time_pretransfer},%{time_starttransfer},%{time_total},%{speed_upload}" $url
        $p = $out.Split(',')
    }

    if ($respFile -ne "NUL") {
        $js = 'try{const a=JSON.parse(require("fs").readFileSync(process.argv[1]));console.log(Array.isArray(a)?a.length:-1)}catch(e){console.log(-2)}'
        $count = node -e $js $respFile
    } else {
        $count = ""
    }

    $server = [math]::Round([double]$p[3] - [double]$p[2], 3)

    "$($req.name),$label,$i,$phase,$($p[0]),$($p[1]),$($p[2]),$($p[3]),$($p[4]),$($p[5]),$count,$server" | Add-Content $csv
    Write-Host ("{0,-12} {1,-10} {2,-7} rep {3,2} : HTTP {4}  count {5}  server {6}s" -f $req.name, $label, $phase, $i, $p[0], $count, $server) -ForegroundColor Gray

    if ($p[0] -ne "200") {
        Write-Host "    -> non-200 ($($p[0])) on $($req.name)/$label : sample DISQUALIFIED" -ForegroundColor DarkYellow
        return $null
    }
    return $server
}

# ---------- run one full capture (warmup + measure) under a given label ----------
function Run-Phase($label, $titleColor) {
    Write-Host "`n########## $($label.ToUpper()) : WARMUP ($warmups passes) ##########" -ForegroundColor $titleColor
    for ($i = 1; $i -le $warmups; $i++) {
        Refresh-TokenIfNeeded
        foreach ($req in $requests) { Invoke-Bench $req $label $i "warmup" | Out-Null }
    }
    Write-Host "`n########## $($label.ToUpper()) : MEASURE ($reps passes) ##########" -ForegroundColor $titleColor
    $fails = 0
    for ($i = 1; $i -le $reps; $i++) {
        Refresh-TokenIfNeeded
        foreach ($req in $requests) {
            $s = Invoke-Bench $req $label $i "measure"
            if ($null -eq $s) { $fails++ }
        }
    }
    return $fails
}

# ============================================================
# PHASE 1 - BEFORE (current deployment) -> label "baseline"
# ============================================================
Write-Host "`n=== Health check BEFORE deploy ===" -ForegroundColor Cyan
$codeBefore = Test-Host
if ($codeBefore -ne "200") {
    Write-Host "Host is not healthy BEFORE deploy (HTTP $codeBefore). Aborting - nothing captured." -ForegroundColor Red
    exit 2
}
Write-Host "  $hostUrl -> HTTP 200 (up)" -ForegroundColor Green
$blFails = Run-Phase "baseline" "Green"

# ============================================================
# DEPLOY blackbird in place - GitLab automation (optional) or manual pause
# ============================================================
Write-Host "`n============================================================" -ForegroundColor Yellow
Write-Host " BEFORE capture complete." -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Yellow

# Try optional GitLab automation. Returns $true (deployed), $false (deploy failed),
# or $null (not configured / declined / unavailable -> fall back to manual).
$gitlabDone = $null
$glScript = Join-Path $PSScriptRoot "gitlab.ps1"
if (Test-Path $glScript) {
    . $glScript
    try { $gitlabDone = Invoke-GitlabDeploy -Environment $Environment } catch {
        Write-Host "GitLab automation error (ignored, manual fallback): $($_.Exception.Message)" -ForegroundColor DarkYellow
        $gitlabDone = $null
    }
    if ($script:glLogFile) { Write-Host "GitLab deploy log: $script:glLogFile" -ForegroundColor DarkGray }
}

if ($gitlabDone -eq $true) {
    Write-Host "GitLab reports $Environment deployed. Proceeding to AFTER capture." -ForegroundColor Green
} elseif ($gitlabDone -eq $false) {
    Write-Host "GitLab deploy did not succeed. Aborting - no AFTER capture, no comparison." -ForegroundColor Red
    Write-Host "BEFORE data is saved in $runDir. Fix the deploy and re-run." -ForegroundColor Red
    exit 2
} else {
    # not configured / declined / unavailable -> original manual pause
    Write-Host " Deploy the BLACKBIRD build onto $hostUrl now." -ForegroundColor Yellow
    Write-Host " Wait until the deployment is fully healthy, THEN continue." -ForegroundColor Yellow
    Read-Host "Press ENTER once blackbird is deployed and healthy to capture AFTER"
}

# ============================================================
# PHASE 2 - AFTER (blackbird deployed) -> label "blackbird"
# ============================================================
Write-Host "`n=== Health check AFTER deploy ===" -ForegroundColor Cyan
$codeAfter = Test-Host
if ($codeAfter -ne "200") {
    Write-Host "Host is not healthy AFTER deploy (HTTP $codeAfter)." -ForegroundColor Red
    Write-Host "The blackbird deployment appears to be down or still rolling out." -ForegroundColor Red
    Write-Host "BEFORE data was captured, but no AFTER data and no comparison will be produced." -ForegroundColor Red
    Write-Host "Bring blackbird up and re-run, or capture AFTER separately." -ForegroundColor Red
    exit 2
}
Write-Host "  $hostUrl -> HTTP 200 (up)" -ForegroundColor Green
$bbFails = Run-Phase "blackbird" "Cyan"

# ============================================================
# Summary
# ============================================================
Write-Host "`n================= PAIRED CAPTURE COMPLETE ($Environment) =================" -ForegroundColor Yellow
Write-Host ("disqualified samples -> before(baseline): {0}   after(blackbird): {1}" -f $blFails, $bbFails) -ForegroundColor Yellow
if ($bbFails -gt 0) {
    Write-Host "WARNING: blackbird (after) returned non-200 on $bbFails measured calls. Treat results with caution." -ForegroundColor Red
}
Write-Host "Run folder: $runDir"
Write-Host "Now run:  node compare.js `"$runDir`"   and   node report.js `"$runDir`"" -ForegroundColor DarkGray
