// Copyright (c) 2026 Azhar Ahmed. All rights reserved.
// MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

// summary.js - writes summary.csv from a run folder's metrics.csv
// Produces: one row per request x label (per-request sheet) + one OVERALL row per label.
const fs = require("fs");
const dir = process.argv[2] || ".";

const csvPath = dir + "/metrics.csv";
if (!fs.existsSync(csvPath)) { console.error("summary.js: metrics.csv not found in '"+dir+"'."); process.exit(1); }
const raw = fs.readFileSync(csvPath,"utf8").trim();
if (!raw || raw.split("\n").length < 2) { console.error("summary.js: metrics.csv has no data rows."); process.exit(1); }
const rows = raw.split("\n").slice(1).map(l => {
  const c = l.split(",");
  if (c.length < 12) return null;
  const num=(v)=>{const n=+v;return Number.isFinite(n)?n:0;};
  return { req:c[0], label:c[1], rep:num(c[2]), phase:c[3], code:c[4], bytes:num(c[5]),
           pre:num(c[6]), ttfb:num(c[7]), total:num(c[8]), ul:num(c[9]), count:num(c[10]), server:num(c[11]) };
}).filter(Boolean);
const M = rows.filter(r => r.phase === "measure");
const reqs = [...new Set(M.map(r => r.req))];
const labels = [...new Set(M.map(r => r.label))];

const mean = a => a.length ? a.reduce((x,y)=>x+y,0)/a.length : 0;
const sd = a => { const m = mean(a); return Math.sqrt(mean(a.map(x=>(x-m)**2))); };
const pct = (a,p) => a.length ? a[Math.min(a.length-1, Math.ceil(p/100*a.length)-1)] : 0;
const f3 = x => x.toFixed(3), f1 = x => x.toFixed(1), f2 = x => x.toFixed(2);

function statsFor(set, bytesHint) {
  const ok = set.filter(r => r.code === "200");
  const fails = set.length - ok.length;
  if (!ok.length) return { n:0, fails, mean:0, p50:0, p95:0, p99:0, max:0, cv:0, mbps:0, bytes:bytesHint||0 };
  const s = ok.map(r => r.server).sort((a,b)=>a-b);
  const m = mean(s);
  const bytes = ok[0].bytes;
  return {
    n: ok.length, fails,
    mean: m, p50: pct(s,50), p95: pct(s,95), p99: pct(s,99), max: s[s.length-1],
    cv: m>0 ? sd(s)/m*100 : 0,
    mbps: m>0 ? (bytes/1048576)/m : 0,
    bytes
  };
}

const header = "scope,request,label,n,failed,mean_s,p50_s,p95_s,p99_s,max_s,cv_pct,throughput_MBps,resp_MB";
const lines = [header];

// per-request rows
for (const req of reqs) {
  for (const label of labels) {
    const st = statsFor(M.filter(r => r.req===req && r.label===label));
    lines.push([
      "request", req, label, st.n, st.fails,
      f3(st.mean), f3(st.p50), f3(st.p95), f3(st.p99), f3(st.max),
      f1(st.cv), f1(st.mbps), f2(st.bytes/1048576)
    ].join(","));
  }
}

// overall rows (all requests pooled, per label)
for (const label of labels) {
  const st = statsFor(M.filter(r => r.label===label));
  const totBytes = M.filter(r => r.label===label && r.code==="200").reduce((x,r)=>x+r.bytes,0);
  lines.push([
    "OVERALL", "(all requests)", label, st.n, st.fails,
    f3(st.mean), f3(st.p50), f3(st.p95), f3(st.p99), f3(st.max),
    f1(st.cv), f1(st.mbps), f2(totBytes/1048576)
  ].join(","));
}

fs.writeFileSync(dir + "/summary.csv", lines.join("\n") + "\n");
console.log("Wrote summary.csv (" + (reqs.length*labels.length) + " request rows + " + labels.length + " overall rows)");
