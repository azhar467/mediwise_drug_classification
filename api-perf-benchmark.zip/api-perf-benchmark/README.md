# API Performance Benchmark

A reusable **latency comparison harness** for HTTP services: replay requests from a Postman
collection against two builds or environments, measure **server-side time**
(time-to-first-byte minus connection setup, so network transfer doesn't pollute the comparison),
verify the two produce identical output, and report — with statistical backing — whether the
candidate is genuinely faster.

> **Adopting this for another team?** See **`ADOPTING.md`** — most teams need only edit config
> files (`report.config.json`, `creds.json`, `config.json`) and drop in their collection, with a
> couple of small code touchpoints for non-standard auth or CI. It also has an honest
> "is this tool right for you?" section so you can self-select before investing time.

The two sides being compared are generic by default (**reference** vs **candidate**); rename them
in `report.config.json`. Originally built for a serializer migration, hence the optional
"deploy the candidate in place" (paired) mode.

Two run modes:

- **Interleaved A/B** — two live hosts (baseline + blackbird), requests alternated in one run.
  Strongest comparison; drift cancels out. Use in **test**.
- **Before / After (paired)** — one host, capture baseline → deploy blackbird in place → capture again.
  Matches how **preprod/prod** promotions work. Less robust to drift; run on a quiet box.
- **Cross-env A/B** — compare any two creds.json environments head-to-head (e.g. test vs preprod,
  test vs performance), interleaved. Pick the two environments at the menu.
- **Batch** — run several environment pairs back to back, each producing its own report. Enter pairs
  like `1-2, 1-3, 3-4` (numbers refer to the environment list).

> All comparisons are **interleaved (alternating A then B)**, never simultaneous. This is deliberate:
> firing both targets at once from one machine introduces client-side contention that biases the
> timings. Concurrency is a load-test question (a different tool), not a latency-comparison one.

## Quick start

1. Put your Postman collection `.json` file(s) in the `collections\` folder.
2. Fill in `creds.json` (copy from `creds.example.json` — see below).
3. Double-click **`run.bat`** (or `powershell -File menu.ps1`).
4. Answer the prompts: mode → collection → requests → reps/warmups (→ environment, for paired).
5. The dashboard opens automatically. All outputs land in a timestamped run folder.

## Requirements

- Windows + PowerShell
- **Node.js** on PATH (`node -v` should work) — used for extraction, stats, compare, report
- **curl.exe** (ships with Windows 10+) — used by the benchmark scripts

## Outputs (per run, inside `runs\<mode>_<collection>_<timestamp>_repsN_warmM\`)

| File | What it is |
|------|------------|
| `metrics.csv` | Raw per-call data (one row per request × label × rep × phase) |
| `summary.csv` | Per-request stats + an OVERALL row per environment |
| `dashboard.html` | Full report: recommendation, charts, run-quality checks, detail table |
| `run_context.json` | Mode / collection / environment / reps / warmups for this run |
| `responses\<label>\` | First measured response body per request (for equivalence check) |

`runs\index.html` is a history page across **all** runs, with a diff between the two latest.

## creds.json

Token endpoint is **shared**; only secrets and the app host change per environment:

```json
{
  "tokenUrl": "https://auth.shared.../oauth/token",
  "baseline":  { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-test.../" },
  "blackbird": { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-blackbird-testing.../" },
  "preprod":   { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-preprod.../" },
  "prod":      { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-prod.../" }
}
```

Interleaved mode uses `baseline` + `blackbird`. Paired mode uses whichever environment you pick
(e.g. `preprod`). `creds.json` is secrets — do not commit it.

## config.json

Defaults the menu pre-fills, and thresholds for the dashboard's Run-quality checks:

- `defaults.reps` / `defaults.warmups` — pre-filled at the prompt (still overridable)
- `thresholds.warmupDriftPct` (8) — warmup halves differing by more than this → "not warm yet"
- `thresholds.measureDriftPct` (5) — drift across the measure window → flag
- `thresholds.significanceP` (0.05) — p-value below which a win counts as significant
- `thresholds.outlierIqrMult` (1.5) — Tukey IQR multiplier for outliers
- `thresholds.trimFraction` (0.1) — tail fraction for the trimmed mean

## Files

| File | Role |
|------|------|
| `run.bat` | Entry point — launches the menu |
| `menu.ps1` | Orchestrator: pick mode/collection/requests/reps, run, then summary + compare + report + history |
| `extract.js` | Pulls PUT request name/path/body from a Postman collection → `requests.json` |
| `bench.ps1` | Interleaved A/B benchmark (two hosts) |
| `bench-paired.ps1` | Before/after benchmark (one host, deploy in the middle) |
| `summary.js` | Writes `summary.csv` |
| `compare.js` | Semantic diff of baseline vs blackbird responses (output equivalence) |
| `report.js` | Builds `dashboard.html` (charts, stats, recommendation) |
| `history.js` | Builds `runs\index.html` |
| `chartjs-inline.js` | Chart.js library, inlined into the dashboard so it works **offline** |
| `config.json` | Defaults and thresholds |
| `report.config.json` | Team branding/labels for the dashboard (no code edits needed) |
| `creds.example.json` | Template for `creds.json` |

> `chartjs-inline.js` must stay next to `report.js` (read at generation time). If you move
> `report.js`, move that file too.

## How a paired (before/after) run works

1. Health-check the host. If it's not returning HTTP 200, it aborts — no comparison.
2. Capture **baseline** (warmup + measure).
3. **Pause** — you deploy blackbird onto the same host, wait until healthy, press Enter.
4. Re-health-check. If the deploy is down/unhealthy, it aborts with baseline saved but no comparison.
5. Capture **blackbird** (warmup + measure), then summary/compare/report.

## Reading the dashboard

- **Recommendation** (top) — one-line verdict for a skim reader.
- **Run quality** — whether you can *trust* the numbers (warmup adequacy, drift, outliers, significance),
  independent of who won. Always read this before the charts.
- A down or failing blackbird **cannot** be reported as faster — those samples are disqualified and
  the recommendation refuses to endorse adoption.
- Δ is relative difference of mean server-side time; positive = blackbird faster.
  Per-request significance is a Mann-Whitney U test; the overall Δ carries a 95% confidence interval.

## Optional: GitLab deploy automation (non-prod, paired mode)

Entirely **optional** and isolated — if not configured, declined, or GitLab is unreachable,
paired mode falls back to the manual "deploy, then press Enter" pause. The benchmark itself is
never affected.

When enabled, in **paired** mode the tool can drive the blackbird deploy for you instead of pausing:

1. Asks which **branch** to deploy and confirms it exists.
2. **Confirms with you** before touching anything ("delete and recreate tag `mds-test`? y/N").
3. **Deletes and recreates** the environment's tag (`mds-dev` / `mds-test` / `mds-performance`)
   pointing at your branch — which auto-triggers the pipeline.
4. **Tracks** the pipeline through its stages (build → terminate → deploy), printing progress,
   and **stops on the first failed stage**.
5. On success, proceeds to the AFTER capture. The tool still independently health-checks the host
   before measuring, so a "green" pipeline that isn't actually serving 200s won't be benchmarked.

Setup:
- Set the `GLPAT` environment variable to your GitLab personal access token (never stored on disk).
- Edit `gitlab.config.json`: set `enabled: true`, `apiBase`, `projectId`, and the per-environment
  `tags` map. Jenkins (preprod/prod) is **not** integrated — this is GitLab non-prod only.

Each deploy attempt writes a verbose, timestamped log to `logs\gitlab\deploy_<env>_<timestamp>.log`
(one file per attempt) capturing every step, stage transitions, and full API responses for debugging.
The `GLPAT` token is never written to the log. These logs are separate from the `runs\` folders.

## Notes / limits **Concurrency/load is not in scope.**
- Server-side time excludes network transfer by design; it does not reflect end-to-end client latency.
- A successful response is expected to be a top-level JSON **array**; a non-array body is treated as a
  down/error environment, not a content difference.
