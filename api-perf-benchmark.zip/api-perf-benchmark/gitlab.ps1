# Copyright (c) 2026 Azhar Ahmed. All rights reserved.
# MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

# gitlab.ps1 - OPTIONAL GitLab deploy automation for the benchmark tool.
#
# Public entry point: Invoke-GitlabDeploy -Environment <name>
#   Returns $true if a deploy completed successfully, $false otherwise.
#   Returns $null if GitLab automation is not configured/enabled - the caller
#   should then fall back to its normal manual flow.
#
# Design constraint: this is entirely optional and isolated. If the config is
# missing/disabled, the token is absent, GitLab is unreachable, or the user
# declines the confirmation, NOTHING here aborts the benchmark - the caller just
# proceeds with the manual deploy pause as before.
#
# Pipeline assumption (confirmed): one pipeline per tag push, stages
#   build -> terminate -> deploy. Recreating the tag auto-triggers it.
# Token: read from the GLPAT environment variable (never stored on disk).
#
# Logs: each deploy attempt writes a verbose, timestamped file under logs\gitlab\
# capturing every step and the full API responses. Logs are independent of the
# benchmark runs\ folders. The GLPAT token is NEVER written to the log.

$script:glLogFile = $null

function Start-GitlabLog($environment) {
    $logDir = Join-Path $PSScriptRoot "logs\gitlab"
    if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
    $stamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $script:glLogFile = Join-Path $logDir "deploy_${environment}_${stamp}.log"
    Write-GitlabLog "=== GitLab deploy log : environment=$environment : $(Get-Date -Format o) ==="
    return $script:glLogFile
}

function Write-GitlabLog($text) {
    if ($null -eq $script:glLogFile) { return }
    $line = "[$(Get-Date -Format 'HH:mm:ss')] $text"
    Add-Content -Path $script:glLogFile -Value $line
}

function Write-GitlabLogObject($label, $obj) {
    if ($null -eq $script:glLogFile) { return }
    Add-Content -Path $script:glLogFile -Value "[$(Get-Date -Format 'HH:mm:ss')] --- $label ---"
    try {
        $json = $obj | ConvertTo-Json -Depth 8
        Add-Content -Path $script:glLogFile -Value $json
    } catch {
        Add-Content -Path $script:glLogFile -Value "(could not serialize: $($_.Exception.Message))"
    }
}

function Get-GitlabConfig {
    $path = Join-Path $PSScriptRoot "gitlab.config.json"
    if (-not (Test-Path $path)) { return $null }
    try { $c = Get-Content $path -Raw | ConvertFrom-Json } catch { return $null }
    if (-not $c.enabled) { return $null }
    return $c
}

function Invoke-GitlabApi($cfg, $method, $path, $token, $body) {
    $uri = "$($cfg.apiBase)$path"
    $headers = @{ "PRIVATE-TOKEN" = $token }
    Write-GitlabLog "API $method $path$(if($body){"  body=$body"})"   # token never logged
    try {
        if ($body) {
            $resp = Invoke-RestMethod -Method $method -Uri $uri -Headers $headers -Body $body -ContentType "application/x-www-form-urlencoded" -ErrorAction Stop
        } else {
            $resp = Invoke-RestMethod -Method $method -Uri $uri -Headers $headers -ErrorAction Stop
        }
        Write-GitlabLogObject "RESPONSE $method $path" $resp
        return $resp
    } catch {
        $status = $null
        try { $status = $_.Exception.Response.StatusCode.value__ } catch {}
        Write-GitlabLog "API ERROR $method $path : HTTP $status : $($_.Exception.Message)"
        # capture response body if present
        try {
            $stream = $_.Exception.Response.GetResponseStream()
            if ($stream) { $reader = New-Object System.IO.StreamReader($stream); $errBody = $reader.ReadToEnd(); if ($errBody) { Write-GitlabLog "ERROR BODY: $errBody" } }
        } catch {}
        Write-Host "  GitLab API error ($method $path): $($_.Exception.Message)" -ForegroundColor DarkYellow
        return $null
    }
}

function Invoke-GitlabDeploy {
    param([string]$Environment)

    $cfg = Get-GitlabConfig
    if ($null -eq $cfg) { return $null }   # not configured -> caller falls back

    Start-GitlabLog $Environment | Out-Null
    Write-GitlabLog "config: apiBase=$($cfg.apiBase) projectId=$($cfg.projectId) pollSeconds=$($cfg.pollSeconds) timeoutMinutes=$($cfg.timeoutMinutes)"

    $token = $env:GLPAT
    if ([string]::IsNullOrWhiteSpace($token)) {
        Write-GitlabLog "ABORT: GLPAT not set -> manual fallback"
        Write-Host "GitLab automation is enabled but GLPAT env var is not set. Skipping - manual deploy." -ForegroundColor DarkYellow
        return $null
    }

    $tag = $cfg.tags.$Environment
    if ([string]::IsNullOrWhiteSpace($tag)) {
        Write-GitlabLog "ABORT: no tag mapped for '$Environment' -> manual fallback"
        Write-Host "No deploy tag mapped for environment '$Environment' in gitlab.config.json. Skipping - manual deploy." -ForegroundColor DarkYellow
        return $null
    }
    Write-GitlabLog "environment=$Environment tag=$tag"

    $proj = [uri]::EscapeDataString($cfg.projectId)

    # ---- pick the branch to deploy ----
    Write-Host "`n--- GitLab deploy for '$Environment' (tag: $tag) ---" -ForegroundColor Cyan
    $branch = Read-Host "Branch to deploy (e.g. blackbird)"
    if ([string]::IsNullOrWhiteSpace($branch)) {
        Write-GitlabLog "ABORT: no branch given -> manual fallback"
        Write-Host "No branch given. Skipping GitLab automation - manual deploy." -ForegroundColor DarkYellow
        return $null
    }
    Write-GitlabLog "branch=$branch"

    # verify the branch exists (best-effort; non-fatal)
    $br = Invoke-GitlabApi $cfg "GET" "/projects/$proj/repository/branches/$([uri]::EscapeDataString($branch))" $token $null
    if ($null -eq $br) {
        Write-GitlabLog "ABORT: branch '$branch' not confirmed -> manual fallback"
        Write-Host "Could not confirm branch '$branch' exists. Skipping - manual deploy." -ForegroundColor DarkYellow
        return $null
    }

    # ---- confirm tag delete + recreate ----
    Write-Host "About to DELETE and RECREATE tag '$tag' pointing at branch '$branch'." -ForegroundColor Yellow
    Write-Host "This will trigger the build -> terminate -> deploy pipeline on $Environment." -ForegroundColor Yellow
    $confirm = Read-Host "Proceed? (y/N)"
    if ($confirm.Trim().ToLower() -ne "y") {
        Write-GitlabLog "ABORT: user declined tag delete/recreate -> manual fallback"
        Write-Host "Declined. Skipping GitLab automation - manual deploy." -ForegroundColor DarkYellow
        return $null
    }
    Write-GitlabLog "user CONFIRMED delete+recreate of tag $tag on $branch"

    # ---- delete existing tag (ignore 404), then recreate ----
    Write-GitlabLog "deleting tag $tag"
    Write-Host "Deleting tag $tag (if it exists)..." -ForegroundColor DarkGray
    Invoke-GitlabApi $cfg "DELETE" "/projects/$proj/repository/tags/$([uri]::EscapeDataString($tag))" $token $null | Out-Null
    Start-Sleep -Seconds 2

    Write-GitlabLog "creating tag $tag on $branch"
    Write-Host "Creating tag $tag on $branch..." -ForegroundColor DarkGray
    $created = Invoke-GitlabApi $cfg "POST" "/projects/$proj/repository/tags?tag_name=$([uri]::EscapeDataString($tag))&ref=$([uri]::EscapeDataString($branch))" $token $null
    if ($null -eq $created) {
        Write-GitlabLog "RESULT: tag creation FAILED -> abort"
        Write-Host "Tag creation failed. Aborting GitLab deploy (benchmark not affected)." -ForegroundColor Red
        return $false
    }

    # ---- find the pipeline the tag push triggered ----
    Write-Host "Waiting for the pipeline to appear..." -ForegroundColor DarkGray
    $pipeline = $null
    for ($i = 0; $i -lt 12; $i++) {
        Start-Sleep -Seconds 5
        $pipes = Invoke-GitlabApi $cfg "GET" "/projects/$proj/pipelines?ref=$([uri]::EscapeDataString($tag))&order_by=id&sort=desc" $token $null
        if ($pipes -and $pipes.Count -gt 0) { $pipeline = $pipes[0]; break }
    }
    if ($null -eq $pipeline) {
        Write-GitlabLog "RESULT: no pipeline appeared for tag $tag -> abort"
        Write-Host "No pipeline appeared for tag $tag. Check GitLab manually." -ForegroundColor Red
        return $false
    }
    $pid = $pipeline.id
    Write-GitlabLog "tracking pipeline #$pid url=$($pipeline.web_url)"
    Write-Host "Tracking pipeline #$pid : $($pipeline.web_url)" -ForegroundColor Cyan

    # ---- poll pipeline + show per-stage (job) progress, stop on failure ----
    $deadline = (Get-Date).AddMinutes([double]$cfg.timeoutMinutes)
    $lastStatusLine = ""
    while ($true) {
        if ((Get-Date) -gt $deadline) {
            Write-GitlabLog "RESULT: pipeline #$pid TIMEOUT after $($cfg.timeoutMinutes)min -> abort"
            Write-Host "Pipeline #$pid timed out after $($cfg.timeoutMinutes) min. Aborting GitLab deploy." -ForegroundColor Red
            return $false
        }
        $p = Invoke-GitlabApi $cfg "GET" "/projects/$proj/pipelines/$pid" $token $null
        if ($null -eq $p) { Start-Sleep -Seconds ([int]$cfg.pollSeconds); continue }

        # per-job (stage) view
        $jobs = Invoke-GitlabApi $cfg "GET" "/projects/$proj/pipelines/$pid/jobs" $token $null
        if ($jobs) {
            $line = ($jobs | Sort-Object id | ForEach-Object { "$($_.stage):$($_.status)" }) -join "  "
            if ($line -ne $lastStatusLine) { Write-Host "  $line" -ForegroundColor DarkGray; Write-GitlabLog "stages: $line"; $lastStatusLine = $line }
            # stop early on any failed job
            $failed = $jobs | Where-Object { $_.status -eq "failed" }
            if ($failed) {
                Write-GitlabLog "RESULT: stage '$($failed[0].stage)' FAILED -> abort"
                Write-Host "Stage '$($failed[0].stage)' FAILED. Aborting GitLab deploy (benchmark not run)." -ForegroundColor Red
                Write-Host "See: $($pipeline.web_url)" -ForegroundColor Red
                return $false
            }
        }

        switch ($p.status) {
            "success"  { Write-GitlabLog "RESULT: pipeline #$pid SUCCESS"; Write-Host "Pipeline #$pid SUCCESS - $Environment deployed." -ForegroundColor Green; return $true }
            "failed"   { Write-GitlabLog "RESULT: pipeline #$pid FAILED"; Write-Host "Pipeline #$pid FAILED. Aborting GitLab deploy." -ForegroundColor Red; return $false }
            "canceled" { Write-GitlabLog "RESULT: pipeline #$pid CANCELED"; Write-Host "Pipeline #$pid was canceled. Aborting." -ForegroundColor Red; return $false }
            "skipped"  { Write-GitlabLog "RESULT: pipeline #$pid SKIPPED"; Write-Host "Pipeline #$pid skipped. Aborting." -ForegroundColor Red; return $false }
            default    { Start-Sleep -Seconds ([int]$cfg.pollSeconds) }   # running/pending/created
        }
    }
}
