# Adopting this tool for your team

This is a **latency comparison harness** for HTTP services: it replays requests against two
builds or environments, measures server-side time, checks the two produce identical output, and
tells you (with statistical backing) whether the candidate is genuinely faster. It was built for one
team's serializer migration, but the core is reusable. This guide is the "make it yours in an
afternoon" path.

> Read **"Is this tool right for you?"** at the bottom first. If your need is load/throughput
> testing, or your stack is far from the assumptions below, adapt the *methodology* rather than
> forking the code — you'll spend less time.

## What you can change with config alone (no code edits)

| Want to change | Edit |
|----------------|------|
| Report title, authors, reviewer, team | `report.config.json` |
| What the two sides are called on the dashboard | `report.config.json` → `labels` |
| The metric name/definition shown | `report.config.json` |
| Default reps / warmups, analysis thresholds | `config.json` |
| Environments, hosts, secrets | `creds.json` (see `creds.example.json`) |
| Which requests to run | drop your Postman collection in `collections\` |
| GitLab deploy automation (optional) | `gitlab.config.json` + `GLPAT` env var |

If your situation fits the assumptions, **you may not need to touch any code** — just the configs
above plus your collection and creds.

## The 10-minute quickstart

1. Install **Node.js** and ensure `curl.exe` is available (Windows 10+ has it).
2. Copy `creds.example.json` → `creds.json`; fill in your token endpoint, secrets, and host URLs.
3. Put your Postman collection `.json` in `collections\`.
4. Edit `report.config.json` with your title/labels.
5. Run `run.bat`, pick a mode, pick your collection, go.

## Code touchpoints (only if your stack differs)

These are the **specific spots** to edit when config isn't enough. Each is small and localized.

### Auth — `bench.ps1` and `bench-paired.ps1`, function `Get-Token`

The tool assumes **OAuth client-credentials**: it POSTs `grant_type=client_credentials&client_id=…&
client_secret=…&scope=…` to a token URL and reads `access_token` from the JSON response, then sends
`Authorization: Bearer <token>` on each request.

To use a different auth scheme, edit **only `Get-Token`** (it's the single seam):

- **API key / static header** — make `Get-Token` return the key, and change the request header in
  `Invoke-Bench` from `Authorization: Bearer …` to your header (e.g. `X-API-Key: …`).
- **Basic auth** — return a base64 `user:pass`, send `Authorization: Basic …`.
- **No auth** — make `Get-Token` return an empty string and drop the auth header.
- **Different OAuth flow** — change the POST body/fields in `Get-Token`; the rest is unaffected.

Search for `Authorization: Bearer` (the request header) and `Get-Token` (the token fetch) — those two
places are the entire auth surface.

### Request method / source — `extract.js`

Assumes **PUT** requests pulled from a **Postman collection**. To change:

- **Other HTTP method** — in `extract.js`, change the `r.method !== "PUT"` filter; in the bench
  scripts, change `-X PUT` in the `curl.exe` calls.
- **Different request source** (OpenAPI, HAR, a hand-written `requests.json`) — replace `extract.js`.
  Its only contract is to write `requests.json` as an array of `{ name, path, body }`. Anything that
  produces that file works; the rest of the pipeline doesn't care where it came from.

### Response equivalence — `compare.js` and the element-count logic

Assumes successful responses are **top-level JSON arrays** (used for the equivalence check and the
"is it down?" detection). If your API returns objects or envelopes:

- In `compare.js`, the `Array.isArray` checks treat a non-array as "down/error." Relax that to accept
  your shape (the canonical-diff logic already handles arbitrary JSON; only the array gate is strict).
- In `report.js` / `summary.js`, `array_count` will be `-1` for non-arrays — harmless, but the
  "elements" column won't be meaningful. Remove or relabel it if it's noise for you.

### CI/CD deploy hook — `gitlab.ps1` (optional, paired mode only)

Used only in **before/after (paired)** mode to deploy the candidate in place. It's GitLab-specific
(recreate a tag → poll one pipeline through build→terminate→deploy). To adapt:

- **Different CI (Jenkins, GitHub Actions, etc.)** — `gitlab.ps1` exposes one contract:
  `Invoke-GitlabDeploy -Environment <name>` returns `$true` (deployed), `$false` (failed), or `$null`
  (not configured → fall back to the manual pause). Write your own `Invoke-<Yourci>Deploy` with the
  same three return values, and change the one call in `bench-paired.ps1` that invokes it.
- **No automation** — do nothing. Leave `gitlab.config.json` `enabled:false` and the tool uses the
  manual "deploy, then press Enter" pause. This is the default.

### Hosts / platform

Host URLs come from `creds.json` (`hostUrl` per environment), so no code change needed. The
orchestration is **Windows/PowerShell/.bat**; the measurement core is `curl` + Node. Porting to
Mac/Linux means rewriting `run.bat` and the `.ps1` orchestration (the Node pieces are
cross-platform already) — that's the one genuinely large adaptation.

## Is this tool right for you?

**Good fit — use it largely as-is:**
- Comparing two versions/environments of a JSON HTTP API for **latency**, where output should stay
  identical (serializer swaps, framework upgrades, refactors, "prove this didn't regress").
- You're on Windows, with OAuth client-credentials and reachable host URLs.
- You want rigor: interleaving, warmup checks, significance testing, output-equivalence gating.

**Adapt the methodology, not the code — you'll fork too much:**
- Your responses aren't top-level JSON arrays, or aren't JSON at all.
- You're on Mac/Linux only, or use a different auth scheme — doable, but it's real editing.
- Different CI system for the deploy step (the hook is swappable, but it's code).

**Wrong tool — look elsewhere:**
- You need **load / concurrency / throughput** testing. This is deliberately single-stream latency.
  Use k6, Gatling, JMeter, or Locust.
- You need end-to-end client latency including network — this measures the server slice on purpose.
- You want a supported product with an owner. This is a sharp internal instrument, not a platform.

## What's portable even if the code isn't

The valuable, transferable part is the **measurement rigor**, not the PowerShell:
interleaved A/B so drift cancels out · measuring the server-side slice to exclude network noise ·
warmup-adequacy checks · Mann-Whitney significance so you don't ship noise as a win ·
output-equivalence gating so a "faster" build that changed the response can't pass ·
health-gating so a down environment can't be reported as faster. Borrow those ideas even if you
write your own harness.
