// Copyright (c) 2026 Azhar Ahmed. All rights reserved.
// MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

// compare.js — semantic diff of responses/resp_<req>_baseline_measure_1.json vs blackbird
const fs = require("fs");
const dir = process.argv[2] || ".";
function canon(x){ if(Array.isArray(x)) return x.map(canon);
  if(x && typeof x==="object") return Object.keys(x).sort().reduce((o,k)=>(o[k]=canon(x[k]),o),{});
  return x; }
const reqs = JSON.parse(fs.readFileSync("requests.json","utf8")).map(r=>r.name);
let allOk = true;
let anyDown = false;
for (const name of reqs) {
  let a, b;
  // ---- load baseline ----
  try {
    a = JSON.parse(fs.readFileSync(`${dir}/responses/baseline/resp_${name}_measure_1.json`,"utf8"));
  } catch(e) { console.log(`MISSING  ${name}  (baseline: ${e.message.split("\n")[0]})`); allOk = false; continue; }
  // ---- load blackbird ----
  try {
    b = JSON.parse(fs.readFileSync(`${dir}/responses/blackbird/resp_${name}_measure_1.json`,"utf8"));
  } catch(e) { console.log(`MISSING  ${name}  (blackbird: ${e.message.split("\n")[0]})`); allOk = false; continue; }

  // ---- health gate: a valid response is a JSON ARRAY. A down/unhealthy env
  // usually returns an error object/string (e.g. {"message":"Service Unavailable"}),
  // which parses fine but is NOT the expected payload. Report that as DOWN/error,
  // not as a content DIFFER, so a terminated environment isn't mistaken for a diff.
  if (!Array.isArray(a)) {
    console.log(`DOWN     ${name}  (baseline returned non-array body: ${preview(a)})`);
    allOk = false; anyDown = true; continue;
  }
  if (!Array.isArray(b)) {
    console.log(`DOWN     ${name}  (blackbird returned non-array body: ${preview(b)})`);
    allOk = false; anyDown = true; continue;
  }

  const eq = JSON.stringify(canon(a)) === JSON.stringify(canon(b));
  console.log(`${eq ? "MATCH   " : "DIFFER  "} ${name}`);
  if (!eq) allOk = false;
}

function preview(v){
  try { const s = typeof v === "string" ? v : JSON.stringify(v); return s.length>80 ? s.slice(0,80)+"..." : s; }
  catch(e){ return String(v); }
}

if (anyDown) {
  console.log("\nOne or more environments returned an error body instead of data — likely down/terminated. Fix deployment before comparing.");
} else {
  console.log(allOk ? "\nAll responses semantically identical." : "\nDifferences found — inspect before presenting.");
}
