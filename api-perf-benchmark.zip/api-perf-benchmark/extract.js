// Copyright (c) 2026 Azhar Ahmed. All rights reserved.
// MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

// extract.js — extract PUT request bodies + paths from a Postman collection
const fs = require("fs");

const inputFile = process.argv[2] || "BlackBird Peformance TEST.postman_collection.json";
const col = JSON.parse(fs.readFileSync(inputFile, "utf8"));
const out = [];

const sanitizeName = n => n.replace(/[^\w-]/g, "_");

// Pull path segments out of a Postman url field, which may be an object
// ({ path: [...] } or { raw: "..." }) or a plain string. Returns an array
// of segments with any {{host-like}} leading segments to be filtered by caller.
const urlSegs = url => {
  if (!url) return [];
  if (typeof url === "string") {
    // string form, e.g. "{{baseUrl}}/parties/q" or a full URL — take the path part
    const noProto = url.replace(/^[a-z]+:\/\//i, "");      // strip scheme
    const afterHost = noProto.split("?")[0].split("/");    // drop query, split on /
    afterHost.shift();                                     // drop host segment
    return afterHost.filter(Boolean);
  }
  if (Array.isArray(url.path)) return url.path;
  if (typeof url.raw === "string") return urlSegs(url.raw);
  return [];
};

(function walk(items) {
  for (const it of items) {
    if (it.item) { walk(it.item); continue; }
    const r = it.request;
    if (!r || r.method !== "PUT" || !r.body || !r.body.raw) continue;

    // path: drop {{host-like}} leading segments, keep the rest
    const segs = urlSegs(r.url).filter(s => !/^\{\{.*\}\}$/.test(s));
    const path = "/" + segs.join("/");

    const body = r.body.raw;
    if (/\{\{/.test(path)) console.log(`WARNING: ${it.name} — path still has variables: ${path}`);
    if (/\{\{/.test(body)) console.log(`WARNING: ${it.name} — body contains {{variables}}, fix in requests.json`);
    if (path === "/") console.log(`WARNING: ${it.name} — empty path extracted; check the url field in the collection`);

    out.push({ name: sanitizeName(it.name), path, body });
  }
})(col.item);

fs.writeFileSync("requests.json", JSON.stringify(out, null, 2));

console.log(`\nExtracted ${out.length} PUT requests:`);
out.forEach((r, i) => console.log(`  [${i + 1}] ${r.name}  ->  ${r.path}`));

// readable log with full bodies
fs.writeFileSync("requests.log.txt",
  out.map((r, i) => {
    let b; try { b = JSON.stringify(JSON.parse(r.body), null, 2); } catch { b = r.body; }
    return `--- [${i + 1}] ${r.name}  ${r.path} ---\n${b}\n`;
  }).join("\n")
);
console.log("Log saved to requests.log.txt");
