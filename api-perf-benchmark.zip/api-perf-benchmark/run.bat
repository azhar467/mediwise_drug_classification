REM Copyright (c) 2026 Azhar Ahmed. All rights reserved.
REM MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel
@echo off
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File ".\menu.ps1"
echo.
echo Press any key to close . . .
pause >nul
