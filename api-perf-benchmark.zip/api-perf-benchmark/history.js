// Copyright (c) 2026 Azhar Ahmed. All rights reserved.
// MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

// history.js - builds runs/index.html: a table of all past runs with headline numbers.
const fs = require("fs");
const path = require("path");
const runsDir = process.argv[2] || "runs";

if (!fs.existsSync(runsDir)) { console.log("no runs/ folder yet"); process.exit(0); }

const dirs = fs.readdirSync(runsDir, { withFileTypes:true })
  .filter(d => d.isDirectory())
  .map(d => d.name);

const rowsData = [];
for (const name of dirs) {
  const full = path.join(runsDir, name);
  let ctx = {}, summary = null;
  try { ctx = JSON.parse(fs.readFileSync(path.join(full,"run_context.json"),"utf8")); } catch(e){}
  // pull the OVERALL rows from summary.csv if present
  let blackbirdMean=null, baselineMean=null, fails=null;
  try {
    const lines = fs.readFileSync(path.join(full,"summary.csv"),"utf8").trim().split("\n");
    const hdr = lines[0].split(",");
    const iLabel=hdr.indexOf("label"), iMean=hdr.indexOf("mean_s"), iFail=hdr.indexOf("failed"), iScope=hdr.indexOf("scope");
    let f=0;
    for (const l of lines.slice(1)) {
      const c=l.split(",");
      if (c[iScope]==="OVERALL") {
        if (c[iLabel]==="blackbird") blackbirdMean=+c[iMean];
        if (c[iLabel]==="baseline")  baselineMean=+c[iMean];
      }
      f += (+c[iFail]||0);
    }
    fails=f;
  } catch(e){}
  const hasDash = fs.existsSync(path.join(full,"dashboard.html"));
  const delta = (baselineMean!=null && blackbirdMean!=null && Math.max(baselineMean,blackbirdMean)>0)
    ? (baselineMean-blackbirdMean)/Math.max(baselineMean,blackbirdMean)*100 : null;
  rowsData.push({ name, ctx, baselineMean, blackbirdMean, delta, fails, hasDash });
}
// newest first by folder name (timestamps sort lexically)
rowsData.sort((a,b)=>a.name<b.name?1:-1);

const f1=x=>x==null?"—":x.toFixed(1), f3=x=>x==null?"—":x.toFixed(3);

// diff the two most recent runs (same B metric) so you can see movement build-to-build
let diffBanner="";
if (rowsData.length>=2) {
  const cur=rowsData[0], prev=rowsData[1];
  if (cur.blackbirdMean!=null && prev.blackbirdMean!=null && prev.blackbirdMean>0) {
    const chg=(prev.blackbirdMean-cur.blackbirdMean)/prev.blackbirdMean*100; // +ve = newer is faster
    const cls=chg>=0?"pos":"neg";
    diffBanner=`<div class="diff"><b>Latest vs previous:</b> ${cur.ctx.collection||"?"} (${cur.ctx.mode||"?"}) — ${cur.name.split("_").slice(-3).join("_")} vs ${prev.name.split("_").slice(-3).join("_")}: `
      + `blackbird mean ${f3(prev.blackbirdMean)}s → ${f3(cur.blackbirdMean)}s `
      + `(<span class="${cls}">${chg>=0?"+":""}${f1(chg)}%</span> ${chg>=0?"faster":"slower"}).</div>`;
  }
}
const trs = rowsData.map(r=>{
  const c=r.ctx;
  const dCls = r.delta==null?"":(r.delta>0?"pos":"neg");
  const link = r.hasDash ? `<a href="${encodeURIComponent(r.name)}/dashboard.html">open</a>` : "—";
  return `<tr>
    <td class="mode">${c.mode||"?"}${c.envA&&c.envB?` · ${c.envA} vs ${c.envB}`:(c.mode==="paired"&&c.environment?` · ${c.environment}`:"")}</td>
    <td class="col">${c.collection||"?"}</td>
    <td>${c.reps??"?"}/${c.warmups??"?"}</td>
    <td>${f3(r.baselineMean)}</td>
    <td>${f3(r.blackbirdMean)}</td>
    <td class="${dCls}">${r.delta==null?"—":(r.delta>0?"+":"")+f1(r.delta)+"%"}</td>
    <td>${r.fails??"—"}</td>
    <td>${link}</td>
    <td class="name">${r.name}</td>
  </tr>`;
}).join("");

const html=`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Benchmark run history</title>
<style>
  body{font-family:Inter,-apple-system,Segoe UI,Arial,sans-serif;color:#1a1d21;background:#f2f4f6;margin:0}
  .wrap{max-width:1080px;margin:0 auto;padding:32px 24px 64px}
  h1{font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:#5b6470;font-weight:600;margin:0 0 4px}
  h2{font-size:28px;margin:0 0 20px;font-weight:700}
  table{border-collapse:collapse;width:100%;background:#fff;border:1px solid #e2e6ea;border-radius:12px;overflow:hidden;font-size:13px}
  th,td{border-bottom:1px solid #e2e6ea;padding:10px 12px;text-align:center}
  th{background:#fbfcfd;color:#5b6470;text-transform:uppercase;font-size:10.5px;letter-spacing:.04em;font-weight:600}
  td.mode{font-weight:600;text-align:left}td.col{text-align:left;color:#5b6470;max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  td.name{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11px;color:#9aa3ad;text-align:left}
  .pos{color:#1f7a4d;font-weight:700}.neg{color:#b3401f;font-weight:700}
  a{color:#1f7a4d;font-weight:600;text-decoration:none}a:hover{text-decoration:underline}
  .empty{color:#5b6470;padding:24px;text-align:center}
  .diff{background:#fff;border:1px solid #e2e6ea;border-left:4px solid #1f7a4d;border-radius:0 10px 10px 0;padding:12px 16px;margin:0 0 16px;font-size:13.5px}
</style></head><body><div class="wrap">
<h1>Blackbird Benchmark</h1><h2>Run history (${rowsData.length})</h2>
${diffBanner}
${rowsData.length? `<table><thead><tr><th>mode</th><th>collection</th><th>reps/warm</th><th>baseline mean s</th><th>blackbird mean s</th><th>Δ</th><th>fails</th><th>report</th><th>folder</th></tr></thead><tbody>${trs}</tbody></table>` : `<div class="empty">No runs yet.</div>`}
<p style="color:#9aa3ad;font-size:11.5px;margin-top:14px">Δ = overall mean server-time improvement of blackbird vs baseline (positive = faster). Generated ${new Date().toLocaleString()}.</p>
</div></body></html>`;

fs.writeFileSync(path.join(runsDir,"index.html"), html);
console.log("Wrote " + path.join(runsDir,"index.html") + " (" + rowsData.length + " runs)");
