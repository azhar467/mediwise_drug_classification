# Copyright (c) 2026 Azhar Ahmed. All rights reserved.
# MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

# menu.ps1 - master entry point for the Blackbird benchmark tool.
# Modes: interleaved A/B (baseline vs blackbird) | before/after paired |
#        cross-env A/B (any two creds entries)   | batch (many pairs)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# defaults from config.json
$defReps = 30; $defWarm = 10
try {
    $cfg = Get-Content "config.json" -Raw | ConvertFrom-Json
    if ($cfg.defaults.reps)    { $defReps = [int]$cfg.defaults.reps }
    if ($cfg.defaults.warmups) { $defWarm = [int]$cfg.defaults.warmups }
} catch { }

function Read-IntDefault($prompt, $default, $min) {
    $v = Read-Host "$prompt [default $default]"
    if ([string]::IsNullOrWhiteSpace($v)) { return $default }
    $n = 0
    if ([int]::TryParse($v, [ref]$n) -and $n -ge $min) { return $n }
    Write-Host "  invalid '$v', using $default" -ForegroundColor DarkYellow
    return $default
}

# list selectable environments from creds.json (entries that look like env blocks)
function Get-Envs {
    $c = Get-Content "creds.json" -Raw | ConvertFrom-Json
    $names = @()
    foreach ($p in $c.PSObject.Properties) {
        if ($p.Name -eq "tokenUrl") { continue }
        if ($p.Value -and ($p.Value.PSObject.Properties.Name -contains "id")) { $names += $p.Name }
    }
    return $names
}

# ---------- 1) MODE ----------
Write-Host ""
Write-Host "============== BLACKBIRD BENCHMARK ==============" -ForegroundColor Cyan
Write-Host "Select run mode:"
Write-Host "  1. Interleaved A/B   (baseline vs blackbird, alternating - strongest)"
Write-Host "  2. Before / After    (single host, deploy blackbird in place mid-run)"
Write-Host "  3. Cross-env A/B     (compare any two environments head-to-head)"
Write-Host "  4. Batch             (run several environment pairs back to back)"
$modeIn = (Read-Host "Mode [1/2/3/4]").Trim()
switch ($modeIn) {
    "2" { $mode = "paired" }
    "3" { $mode = "crossenv" }
    "4" { $mode = "batch" }
    default { $mode = "interleaved" }
}
Write-Host "-> $mode" -ForegroundColor Green

# ---------- 2) COLLECTION ----------
$colDir = Join-Path $PSScriptRoot "collections"
if (-not (Test-Path $colDir)) { New-Item -ItemType Directory -Force -Path $colDir | Out-Null }
$cols = @(Get-ChildItem -Path $colDir -Filter *.json -File | Sort-Object Name)
if ($cols.Count -eq 0) {
    Write-Host "No collections found in '$colDir'." -ForegroundColor Red
    Write-Host "Drop your Postman collection .json file(s) into that folder and re-run." -ForegroundColor Red
    exit 1
}
Write-Host "`n============== SELECT COLLECTION ==============" -ForegroundColor Cyan
for ($i = 0; $i -lt $cols.Count; $i++) { Write-Host ("  {0,2}. {1}" -f ($i+1), $cols[$i].Name) }
$colSel = Read-IntDefault "Collection number" 1 1
if ($colSel -lt 1 -or $colSel -gt $cols.Count) { Write-Host "Out of range." -ForegroundColor Red; exit 1 }
$collection = $cols[$colSel-1].FullName
$collectionName = $cols[$colSel-1].Name
Write-Host "-> $collectionName" -ForegroundColor Green

# ---------- 3) EXTRACT ----------
Write-Host "`n===== Extracting PUT requests from collection =====" -ForegroundColor Cyan
node extract.js "$collection"
if ($LASTEXITCODE -ne 0) { Write-Host "extract.js failed." -ForegroundColor Red; exit 1 }
$reqs = Get-Content "requests.json" -Raw | ConvertFrom-Json
if ($reqs.Count -eq 0) { Write-Host "No PUT requests found in that collection." -ForegroundColor Red; exit 1 }

# ---------- 4) REQUEST SUBSET ----------
Write-Host "`n============== SELECT REQUESTS ==============" -ForegroundColor Cyan
for ($i = 0; $i -lt $reqs.Count; $i++) { Write-Host ("  {0,2}. {1}" -f ($i+1), $reqs[$i].name) }
Write-Host "   all. Run everything"
Write-Host "Enter numbers separated by space/comma (e.g. 1 3 5), or 'all':"
$inp = Read-Host "Selection"
$selected = @()
if ($inp.Trim().ToLower() -eq "all" -or $inp.Trim() -eq "") {
    Write-Host "-> Running ALL $($reqs.Count) requests" -ForegroundColor Green
} else {
    $nums = $inp -split "[,\s]+" | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ }
    foreach ($n in $nums) {
        if ($n -ge 1 -and $n -le $reqs.Count) { $selected += $reqs[$n-1].name }
        else { Write-Host "  (ignoring out-of-range: $n)" -ForegroundColor DarkYellow }
    }
    if ($selected.Count -eq 0) { Write-Host "No valid selections." -ForegroundColor Red; exit 1 }
    Write-Host "-> Running: $($selected -join ', ')" -ForegroundColor Green
}

# ---------- 5) REPS / WARMUPS ----------
Write-Host ""
$reps    = Read-IntDefault "Measured reps per request" $defReps 1
$warmups = Read-IntDefault "Warmup passes per request" $defWarm 0

# ---------- run-one-comparison helper ----------
# $labelA / $labelB are creds.json entry names; internal labels stay baseline/blackbird.
function Invoke-Comparison($labelA, $labelB, $tag) {
    $stamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $colTag = [System.IO.Path]::GetFileNameWithoutExtension($collectionName) -replace '[^\w-]', '_'
    if ($colTag.Length -gt 24) { $colTag = $colTag.Substring(0,24) }
    $runDir = "runs\${tag}_${colTag}_${stamp}_reps${reps}_warm${warmups}"

    Write-Host "`n===== Benchmark: $labelA vs $labelB =====" -ForegroundColor Cyan
    Write-Host "    folder=$runDir  reps=$reps  warmups=$warmups" -ForegroundColor DarkGray
    if ($selected.Count -gt 0) {
        & .\bench.ps1 -LabelA $labelA -LabelB $labelB -Only $selected -Reps $reps -Warmups $warmups -RunDir $runDir
    } else {
        & .\bench.ps1 -LabelA $labelA -LabelB $labelB -Reps $reps -Warmups $warmups -RunDir $runDir
    }
    if ($LASTEXITCODE -ne 0) { Write-Host "Benchmark failed for $labelA vs $labelB (exit $LASTEXITCODE)." -ForegroundColor Red; return $false }

    $runDir = (Get-Content "last_run.txt" -Raw).Trim()
    $ctx = @{ mode=$tag; collection=$collectionName; envA=$labelA; envB=$labelB; reps=$reps; warmups=$warmups } | ConvertTo-Json
    $ctx | Out-File (Join-Path $runDir "run_context.json") -Encoding utf8

    Write-Host "  summary..."; node summary.js "$runDir" | Out-Null
    Write-Host "  compare..."; node compare.js "$runDir" | Out-Null
    Write-Host "  dashboard..."; node report.js "$runDir" | Out-Null
    Write-Host "Done - $runDir" -ForegroundColor Green
    $script:lastRunDir = $runDir
    return $true
}

# ---------- dispatch by mode ----------
$envs = Get-Envs
$script:lastRunDir = ""

if ($mode -eq "paired") {
    $e = Read-Host "creds.json environment to benchmark [default baseline]"
    $env = if ([string]::IsNullOrWhiteSpace($e)) { "baseline" } else { $e.Trim() }
    $stamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $colTag = ([System.IO.Path]::GetFileNameWithoutExtension($collectionName) -replace '[^\w-]', '_')
    if ($colTag.Length -gt 24) { $colTag = $colTag.Substring(0,24) }
    $runDir = "runs\paired_${colTag}_${stamp}_reps${reps}_warm${warmups}"
    Write-Host "`n===== [1/4] Benchmark (paired) =====" -ForegroundColor Cyan
    if ($selected.Count -gt 0) { & .\bench-paired.ps1 -Environment $env -Only $selected -Reps $reps -Warmups $warmups -RunDir $runDir }
    else                       { & .\bench-paired.ps1 -Environment $env -Reps $reps -Warmups $warmups -RunDir $runDir }
    if ($LASTEXITCODE -ne 0) { Write-Host "Benchmark failed (exit $LASTEXITCODE)." -ForegroundColor Red; exit $LASTEXITCODE }
    $runDir = (Get-Content "last_run.txt" -Raw).Trim()
    $ctx = @{ mode="paired"; collection=$collectionName; environment=$env; reps=$reps; warmups=$warmups } | ConvertTo-Json
    $ctx | Out-File (Join-Path $runDir "run_context.json") -Encoding utf8
    node summary.js "$runDir"; node compare.js "$runDir"; node report.js "$runDir"
    $script:lastRunDir = $runDir
}
elseif ($mode -eq "crossenv") {
    Write-Host "`n============== SELECT TWO ENVIRONMENTS ==============" -ForegroundColor Cyan
    for ($i=0; $i -lt $envs.Count; $i++) { Write-Host ("  {0,2}. {1}" -f ($i+1), $envs[$i]) }
    $aSel = Read-IntDefault "Environment A (the 'before'/reference)" 1 1
    $bSel = Read-IntDefault "Environment B (the candidate)" 2 1
    if ($aSel -lt 1 -or $aSel -gt $envs.Count -or $bSel -lt 1 -or $bSel -gt $envs.Count) { Write-Host "Out of range." -ForegroundColor Red; exit 1 }
    if ($aSel -eq $bSel) { Write-Host "A and B must differ." -ForegroundColor Red; exit 1 }
    Invoke-Comparison $envs[$aSel-1] $envs[$bSel-1] "crossenv" | Out-Null
}
elseif ($mode -eq "batch") {
    Write-Host "`n============== BATCH: define pairs ==============" -ForegroundColor Cyan
    for ($i=0; $i -lt $envs.Count; $i++) { Write-Host ("  {0,2}. {1}" -f ($i+1), $envs[$i]) }
    Write-Host "Enter pairs as A-B, separated by commas. Example: 1-2, 1-3, 3-4"
    Write-Host "(each pair is one interleaved A/B run)"
    $pairsIn = Read-Host "Pairs"
    $pairs = @()
    foreach ($tok in ($pairsIn -split ",")) {
        $t = $tok.Trim(); if ($t -eq "") { continue }
        $ab = $t -split "-"
        if ($ab.Count -ne 2) { Write-Host "  (skipping '$t')" -ForegroundColor DarkYellow; continue }
        $a=0; $b=0
        if ([int]::TryParse($ab[0].Trim(),[ref]$a) -and [int]::TryParse($ab[1].Trim(),[ref]$b) `
            -and $a -ge 1 -and $a -le $envs.Count -and $b -ge 1 -and $b -le $envs.Count -and $a -ne $b) {
            $pairs += ,@($envs[$a-1], $envs[$b-1])
        } else { Write-Host "  (skipping invalid pair '$t')" -ForegroundColor DarkYellow }
    }
    if ($pairs.Count -eq 0) { Write-Host "No valid pairs." -ForegroundColor Red; exit 1 }
    Write-Host "-> $($pairs.Count) pair(s) queued" -ForegroundColor Green
    $ok=0; $fail=0
    foreach ($pr in $pairs) {
        if (Invoke-Comparison $pr[0] $pr[1] "batch") { $ok++ } else { $fail++ }
    }
    Write-Host "`nBatch complete: $ok succeeded, $fail failed." -ForegroundColor Yellow
}
else {  # interleaved (default)
    Invoke-Comparison "baseline" "blackbird" "interleaved" | Out-Null
}

# refresh history across all runs, open the most recent dashboard
node history.js "runs" | Out-Null
if ($script:lastRunDir -ne "" -and (Test-Path "$script:lastRunDir\dashboard.html")) {
    Start-Process "$script:lastRunDir\dashboard.html"
}
Write-Host "`nAll done. See runs\index.html for history across runs." -ForegroundColor Green
