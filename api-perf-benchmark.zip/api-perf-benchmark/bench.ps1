# Copyright (c) 2026 Azhar Ahmed. All rights reserved.
# MDS Search | Developer: Ayush Goyal | Architect: Brian Armstrong | PO: Steve Coulter | SM: Natalie Bickel

# ============================================================
# bench.ps1 - Blackbird vs baseline, 5 PUT requests, interleaved A/B
# ============================================================
param(
    [string[]]$Only = @(),
    [int]$Reps = 30,        # measured reps per request per target
    [int]$Warmups = 10,     # discarded warmups per request per target
    [string]$RunDir = "",   # caller-supplied run folder; auto-generated if empty
    [string]$LabelA = "baseline",   # creds.json entry mapped to internal "baseline"
    [string]$LabelB = "blackbird"   # creds.json entry mapped to internal "blackbird"
)
# ---------- CONFIG ----------
$reps     = $Reps
$warmups  = $Warmups
# internal label -> real creds.json entry (lets us compare ANY two environments
# while the downstream pipeline keeps using the fixed baseline/blackbird keys)
$credOf = @{ "baseline" = $LabelA; "blackbird" = $LabelB }
# ---------- CREDENTIALS ----------
# New creds.json shape (token endpoint SHARED across environments):
#   {
#     "tokenUrl": "https://auth.shared.../oauth/token",
#     "baseline":  { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-test.../" },
#     "blackbird": { "id":"...", "secret":"...", "scope":"...", "hostUrl":"https://mds-blackbird-testing.../" }
#   }
# Falls back to the old shape (per-entry .url token endpoint) if tokenUrl is absent.
$creds = Get-Content "creds.json" -Raw | ConvertFrom-Json

function Get-Token($label) {
    $e = $creds.($credOf[$label])
    $tokenUrl = if ($creds.tokenUrl) { $creds.tokenUrl } else { $e.url }
    $resp = curl.exe -k -s -X POST $tokenUrl -d "grant_type=client_credentials&client_id=$($e.id)&client_secret=$($e.secret)&scope=$($e.scope)"
    $tok = ($resp | ConvertFrom-Json).access_token
    if (-not $tok) { Write-Host "TOKEN FETCH FAILED for $label ($($credOf[$label])) : $resp"; exit 1 }
    Write-Host "Token OK for $label = $($credOf[$label]) (len $($tok.Length))"
    return $tok
}

function Refresh-TokensIfNeeded {
    $age = (New-TimeSpan -Start $script:tokenMintedAt -End (Get-Date)).TotalMinutes
    if ($age -ge 45) {
        Write-Host "  (tokens age $([int]$age)min -> refreshing)" -ForegroundColor DarkYellow
        $script:tokens = @{
            "baseline"  = Get-Token "baseline"
            "blackbird" = Get-Token "blackbird"
        }
        Write-Host ("  new baseline token tail: ...{0}" -f $script:tokens['baseline'].Substring($script:tokens['baseline'].Length-6)) -ForegroundColor DarkYellow
        $script:tokenMintedAt = Get-Date
    }
}

$tokens = @{
    "baseline"  = Get-Token "baseline"
    "blackbird" = Get-Token "blackbird"
}
$script:tokenMintedAt = Get-Date

# ----------------------------------
# Host (app) URLs per label. New shape: each creds entry carries its own hostUrl.
# Falls back to the previous hard-coded URLs if hostUrl is absent.
$hosts = @{
    "baseline"  = if ($creds.($credOf["baseline"]).hostUrl)  { $creds.($credOf["baseline"]).hostUrl }  else { "https://mds-test.ch7vfis9ph.us-east-1.elasticbeanstalk.com" }
    "blackbird" = if ($creds.($credOf["blackbird"]).hostUrl) { $creds.($credOf["blackbird"]).hostUrl } else { "https://mds-blackbird-testing.ch7vfis9ph.us-east-1.elasticbeanstalk.com" }
}

# 5 requests: name, path, body file
$requests = Get-Content "requests.json" -Raw | ConvertFrom-Json
# ---- Request selection: empty = run ALL; or list names to run a subset ----
$only = $Only   # e.g. @("parties_q-1","parties_q-5") for a subset; @() runs everything
if ($only.Count -gt 0) {
    $requests = $requests | Where-Object { $only -contains $_.name }
    Write-Host "Running SUBSET: $($requests.name -join ', ')" -ForegroundColor Cyan
} else {
    Write-Host "Running ALL $($requests.Count) requests" -ForegroundColor Cyan
}
if ($requests.Count -eq 0) { Write-Host "No requests matched - check the names against requests.json" -ForegroundColor Red; exit 1 }

# ----------------------------------
# ---- HEALTH PRE-CHECK: make sure both environments are actually up ----
# A terminated / down Elastic Beanstalk env can still answer with a fast
# 4xx/5xx, which would otherwise look like "blackbird faster". We probe each
# host once and refuse to run a comparison against a dead environment.
function Test-Host($label) {
    $url = $hosts[$label]
    $req = $requests[0]
    $probeBody = Join-Path $env:TEMP "bb_probe_$($label).json"
    [System.IO.File]::WriteAllText($probeBody, $req.body)
    $code = curl.exe -k -s -o NUL -X PUT `
        -H "Authorization: Bearer $($script:tokens[$label])" `
        -H "Content-Type: application/json" `
        --data-binary "@$probeBody" `
        -w "%{http_code}" `
        --connect-timeout 10 --max-time 30 `
        ($url + $req.path)
    Remove-Item $probeBody -ErrorAction SilentlyContinue
    if ([string]::IsNullOrWhiteSpace($code)) { $code = "000" }  # curl could not connect
    return $code
}

Write-Host "`n--- Health check ---" -ForegroundColor Cyan
$health = @{}
foreach ($label in @("baseline","blackbird")) {
    $code = Test-Host $label
    $health[$label] = $code
    $ok = ($code -eq "200")
    $color = if ($ok) { "Green" } else { "Red" }
    Write-Host ("  {0,-10} -> HTTP {1} {2}" -f $label, $code, $(if($ok){"(up)"}else{"(DOWN / unhealthy)"})) -ForegroundColor $color
}

# Abort cleanly if either side is not returning a healthy 200.
$baselineUp  = ($health['baseline']  -eq "200")
$blackbirdUp = ($health['blackbird'] -eq "200")
if (-not $blackbirdUp) {
    Write-Host "`nBLACKBIRD is not healthy (HTTP $($health['blackbird'])). Aborting - no comparison will be produced." -ForegroundColor Red
    Write-Host "Bring the blackbird deployment back up (Elastic Beanstalk env may be terminated) and re-run." -ForegroundColor Red
    exit 2
}
if (-not $baselineUp) {
    Write-Host "`nBASELINE is not healthy (HTTP $($health['baseline'])). Aborting - no comparison will be produced." -ForegroundColor Red
    exit 2
}

# ----------------------------------
if ($RunDir -ne "") {
    $runDir = $RunDir
} else {
    $stamp  = Get-Date -Format "yyyy-MM-dd_HHmmss"
    $runDir = "runs\interleaved_${stamp}_reps${reps}_warm${warmups}"
}
New-Item -ItemType Directory -Force -Path $runDir, "$runDir\responses\baseline", "$runDir\responses\blackbird", "$runDir\requests" | Out-Null
$runDir | Out-File "last_run.txt" -Encoding ascii -NoNewline
$csv = "$runDir\metrics.csv"
"request,label,rep,phase,http_code,resp_bytes,pretransfer_s,ttfb_s,total_s,upload_Bps,array_count,server_s" | Out-File $csv -Encoding utf8

function Invoke-Bench($req, $label, $i, $phase) {
    if ($phase -eq "measure" -and $i -eq 1) {
        $respFile = "$runDir\responses\$label\resp_$($req.name)_measure_1.json"
    } else {
        $respFile = "NUL"
    }
    $bodyFile = "$runDir\requests\body_$($req.name).json"
    $url      = $hosts[$label] + $req.path

    [System.IO.File]::WriteAllText("$PWD\$bodyFile", $req.body)

    $out = curl.exe -k -s -o $respFile -X PUT -H "Authorization: Bearer $($script:tokens[$label])" -H "Content-Type: application/json" --data-binary "@$bodyFile" -w "%{http_code},%{size_download},%{time_pretransfer},%{time_starttransfer},%{time_total},%{speed_upload}" $url

    if (-not $out) { Write-Host "CURL FAILED for $($req.name) / $label"; return $null }
    $p = $out.Split(',')

    if ($p[0] -eq "401") {
        Write-Host "  401 on $($req.name)/$label -> refreshing token and retrying" -ForegroundColor DarkYellow
        $script:tokens = @{ "baseline" = Get-Token "baseline"; "blackbird" = Get-Token "blackbird" }
        $script:tokenMintedAt = Get-Date
        $out = curl.exe -k -s -o $respFile -X PUT -H "Authorization: Bearer $($script:tokens[$label])" -H "Content-Type: application/json" --data-binary "@$bodyFile" -w "%{http_code},%{size_download},%{time_pretransfer},%{time_starttransfer},%{time_total},%{speed_upload}" $url
        $p = $out.Split(',')
    }

    if ($respFile -ne "NUL") {
        $js = 'try{const a=JSON.parse(require("fs").readFileSync(process.argv[1]));console.log(Array.isArray(a)?a.length:-1)}catch(e){console.log(-2)}'
        $count = node -e $js $respFile
    } else {
        $count = ""
    }

    $server = [math]::Round([double]$p[3] - [double]$p[2], 3)

    "$($req.name),$label,$i,$phase,$($p[0]),$($p[1]),$($p[2]),$($p[3]),$($p[4]),$($p[5]),$count,$server" | Add-Content $csv
    Write-Host ("{0,-12} {1,-10} {2,-7} rep {3,2} : HTTP {4}  count {5}  server {6}s" -f $req.name, $label, $phase, $i, $p[0], $count, $server) -ForegroundColor Gray

    # IMPORTANT: only a clean 200 counts as a valid timing sample.
    # A down/unhealthy environment returning 4xx/5xx (often very fast) must NOT
    # be allowed to win. Return $null so the caller skips this comparison.
    if ($p[0] -ne "200") {
        Write-Host "    -> non-200 ($($p[0])) on $($req.name)/$label : sample DISQUALIFIED" -ForegroundColor DarkYellow
        return $null
    }
    return $server
}

$script:bbWins = 0
$script:blWins = 0
$script:ties   = 0
$script:bbFails = 0   # measured blackbird calls that did not return a clean 200
$script:blFails = 0   # measured baseline  calls that did not return a clean 200

# ---- WARMUP: full passes over all requests ----
for ($i = 1; $i -le $warmups; $i++) {
    Refresh-TokensIfNeeded
    Write-Host "`n########## WARMUP PASS $i of $warmups ##########"
    foreach ($req in $requests) {
        foreach ($label in @("baseline","blackbird")) { Invoke-Bench $req $label $i "warmup" | Out-Null }
    }
}

# ---- MEASURE: full passes over all requests ----
for ($i = 1; $i -le $reps; $i++) {
    Refresh-TokensIfNeeded
    Write-Host "`n########## MEASURE PASS $i of $reps ##########"
    foreach ($req in $requests) {
        $sBase = (Invoke-Bench $req "baseline"  $i "measure")
        $sBird = (Invoke-Bench $req "blackbird" $i "measure")

        # Count health failures regardless of comparison.
        if ($null -eq $sBase) { $script:blFails++ }
        if ($null -eq $sBird) { $script:bbFails++ }

        # Only compare when BOTH sides produced a valid 200 timing.
        if ($null -ne $sBase -and $null -ne $sBird) {
            if     ($sBird -lt $sBase) { $script:bbWins++; $tag = "BLACKBIRD faster" }
            elseif ($sBird -gt $sBase) { $script:blWins++; $tag = "baseline faster " }
            else                       { $script:ties++;   $tag = "tie             " }
            $total = $script:bbWins + $script:blWins + $script:ties
            Write-Host ("    {0}  | running score  blackbird {1} : {2} baseline ({3} ties, {4} compares)" -f $tag, $script:bbWins, $script:blWins, $script:ties, $total) -ForegroundColor Cyan
        } else {
            Write-Host ("    SKIPPED compare ($($req.name) rep $i) - missing a healthy 200 sample" -f $req.name) -ForegroundColor DarkYellow
        }
    }
}

Write-Host "`n================= LIVE TALLY (per-rep, all requests) =================" -ForegroundColor Yellow
Write-Host ("blackbird faster: {0}   baseline faster: {1}   ties: {2}" -f $script:bbWins, $script:blWins, $script:ties) -ForegroundColor Yellow
Write-Host ("disqualified samples -> blackbird: {0}   baseline: {1}" -f $script:bbFails, $script:blFails) -ForegroundColor Yellow
if ($script:bbFails -gt 0) {
    Write-Host "WARNING: blackbird returned non-200 on $($script:bbFails) measured calls. Treat any 'blackbird faster' result with suspicion." -ForegroundColor Red
}
Write-Host "Run folder: $runDir"
